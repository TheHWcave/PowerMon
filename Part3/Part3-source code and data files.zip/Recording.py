#!/usr/bin/env python3
#MIT License
#
#Copyright (c) 2019 TheHWcave
#
#Permission is hereby granted, free of charge, to any person obtaining a copy
#of this software and associated documentation files (the "Software"), to deal
#in the Software without restriction, including without limitation the rights
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#copies of the Software, and to permit persons to whom the Software is
#furnished to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
#SOFTWARE.
#

from CommonDefs import *
#from LCDpanel import *
#from Buttons import ScanButtons, BUTTON1, BUTTON2, BUTTON3, BUTTON4, NO_EVENT,SHORT_PRESS, LONG_PRESS
from time import sleep,perf_counter,localtime,strftime
from Display import Display
from Measure import Measure


class Recording:
	"""
		handles recording of values in a CSV file format
	"""

	__disp	    = None 
	__data		= None
	__Recording = False
	__RecFile   = None

	__RECTIME	= (0,0,1.0,2.0,5.0,10.0,30.0,60.0,300.0)
	
	__LastTime	  = 0
	__LastVolts   = INVALID
	__LastAmps    = INVALID

	def SetRecording(self,TurnOn):
		"""
			If the parameter is true, starts a new recording if it 
			wasn't on or closes the previous recording first and then 
			starts a new one.
			If the parameter is false, any ongoing recording is stopped 
			and the recording file is closed 
			
			The recording filename is unique and consists of a date and 
			time stamp. The format is a CSV Comma-Separated-Values
			with a header line
		"""
		if TurnOn:
			if self.__Recording:
				self.__RecFile.close() # close previous recording
			fname = HOMEDIR+'Rec/REC_'+strftime('%Y%m%d%H%M%S',localtime())+'.csv'
			self.__RecFile = open(fname,'w')
			self.__RecFile.write('Time[S],Volts[V], Current[A],Power[W],Capacity[Ah],Energy[Wh]\n')
			self.__Recording = True
			self.__disp.SetRecState(True)
		else:
			if self.__Recording:
				self.__RecFile.close() # close recording
				self.__Recording = False
				self.__disp.SetRecState(False)
		return None

	def DoRecording(self, now, Snapshot = False):
		if self.__Recording:
			opt   = self.__data.GetRecOpt()
			volts = self.__data.GetVolts()
			amps  = self.__data.GetCurrent()
			record_it = False
			if  opt == REC_CHANGES:
				if abs(self.__LastVolts - volts) > 0.010 or abs(self.__LastAmps - amps) > 0.001:
					record_it = True
					self.__LastVolts = volts
					self.__LastAmps  = amps
			elif opt == REC_MANUALY:
				if Snapshot: 
					record_it = True
			else:
				if now - self.__LastTime >= self.__RECTIME[opt]:
					record_it = True
					self.__LastTime = now
			if record_it:
				self.__RecFile.write(self.__disp.Running2String(self.__data.GetRunning(),False))
				self.__RecFile.write(','+self.__disp.Volts2String(volts,False))
				self.__RecFile.write(','+self.__disp.Current2String(amps,False))
				self.__RecFile.write(','+self.__disp.Power2String(self.__data.GetPower(),False))
				self.__RecFile.write(','+self.__disp.Capacity2String(self.__data.GetCapacity(),False))
				self.__RecFile.write(','+self.__disp.Energy2String(self.__data.GetEnergy(),False))
				self.__RecFile.write('\n')
		return None
		
	
			
	def __init__(self, disp, data):
		""" setup the class to have access to measurement data to get the 
		    to recorded values from and to the display to tell it about
		    the recording status and use the available string conversion
		    routines 
		"""

		self.__disp      = disp
		self.__data		 = data
		self.__Recording = False
		self.__RecLast   = 0
		 
		self.__disp.SetRecObject(self) # give display access to recording
		
