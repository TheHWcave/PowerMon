#!/usr/bin/env python3
#MIT License
#
#Copyright (c) 2019 TheHWcave
#
#Permission is hereby granted, free of charge, to any person obtaining a copy
#of this software and associated documentation files (the "Software"), to deal
#in the Software without restriction, including without limitation the rights
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#copies of the Software, and to permit persons to whom the Software is
#furnished to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
#SOFTWARE.
#

from CommonDefs import *
from LCDpanel import *
from Buttons import ScanButtons, BUTTON1, BUTTON2, BUTTON3, BUTTON4, NO_EVENT,SHORT_PRESS, LONG_PRESS


class Show:
	"""
		Displays information but does not allow editing.
		
		Before calling "Show" it needs to be initialized with a list of values (strings) 
		through a call to SetValueList
		
		"Show" displays the first pair of strings on 1st row and
		the text PREV     NEXT BACK on second (no select)
		
		returns MENU_PENDING except as shown below:
		Handles the events
		  Button   press     
			1      short   : previous pair, restart at top if needed
			1      long    : (not used)
			2      short   : (not used)
			2      long    : (not used)
			3      short   : next pair, restart down at 0 if needed
			3      long    : (not used)
			4      short   : return MENU_BACK  
			4      long	   : (not used)
			
	"""

	
	__valist	= None


	__firstcall	= True
	__selval	= None
	__cursor	= None

	

	def SetValueList(self,valuelist):	
		"""
			setup a list of value strings that are shown by the ShowVal
			function as pairs of two. Therefore a blank entry is added
			if the given list contains an odd number of entries
		"""
		self.__valist = valuelist
		if  len(valuelist) % 2 != 0:
			self.__valist.append(' ') # make sure list is even
		if self.__selval > len(self.__valist) -2:
			self.__selval = len(self.__valist) -2
		return None

	def ShowVal(self,Ev):
		res = MENU_PENDING
		if self.__firstcall:
			self.__selval = 0
			WriteLCD(0,1,"PRV     NXT BACK")
			self.__firstcall = False
	
		WriteLCD(0,0,self.__valist[self.__selval].ljust(8),False)
		WriteLCD(8,0,self.__valist[self.__selval+1].ljust(8),False)
		
		if Ev == (BUTTON1,SHORT_PRESS): # prev
			if self.__selval > 1:
				self.__selval = self.__selval -2
			else:
				self.__selval = len(self.__valist)-2
		elif Ev == (BUTTON3,SHORT_PRESS): # next
			if self.__selval < len(self.__valist)-2:
				self.__selval = self.__selval +2
			else:
				self.__selval = 0
		elif Ev == (BUTTON4,SHORT_PRESS): # back
			res = MENU_BACK
		
		if res != MENU_PENDING:
			self.__firstcall = True
		return res


	def __init__(self ):
		""" setup a menu of things to show as pairs of value strings
		    no editing is allowed, only moving forwards or backwards
		    between the pairs
		    
			The list of pairs are set by the SetValueList method
			
		"""

		
		self.__valist = None
	
		self.__firstcall = True
		self.__selval = 0

		
