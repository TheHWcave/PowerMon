#!/usr/bin/env python3
#MIT License
#
#Copyright (c) 2019 TheHWcave
#
#Permission is hereby granted, free of charge, to any person obtaining a copy
#of this software and associated documentation files (the "Software"), to deal
#in the Software without restriction, including without limitation the rights
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#copies of the Software, and to permit persons to whom the Software is
#furnished to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
#SOFTWARE.
#
import board
import digitalio
from CommonDefs import *
LCD_RS = digitalio.DigitalInOut(board.D26)
LCD_EN = digitalio.DigitalInOut(board.D19)
LCD_D7 = digitalio.DigitalInOut(board.D27)
LCD_D6 = digitalio.DigitalInOut(board.D22)
LCD_D5 = digitalio.DigitalInOut(board.D24)
LCD_D4 = digitalio.DigitalInOut(board.D25)
LCD_COLUMNS = 16
LCD_ROWS = 2

import adafruit_character_lcd.character_lcd as characterlcd
lcd = characterlcd.Character_LCD_Mono(LCD_RS, LCD_EN, LCD_D4, LCD_D5, LCD_D6, LCD_D7, LCD_COLUMNS, LCD_ROWS)

backlight = digitalio.DigitalInOut(board.D21)
backlight.direction = digitalio.Direction.OUTPUT
backlight.value = True


# CH_HI_PAT = [
	 # 0b10010,
	 # 0b11110,
	 # 0b10010,
	 # 0b00000,
	 # 0b00000,
	 # 0b00000,
	 # 0b00000,
	 # 0b00000]

# CH_LO_PAT = [
	 # 0b00000,
	 # 0b00000,
	 # 0b00000,
	 # 0b00100,
	 # 0b00100,
	 # 0b00100,
	 # 0b00111,
	 # 0b00000]

# CH_HILO_PAT = [
	 # 0b10010,
	 # 0b11110,
	 # 0b10010,
	 # 0b00000,
	 # 0b00100,
	 # 0b00100,
	 # 0b00111,
	 # 0b00000]
	 
# CH_BALL_PAT = [
	 # 0b00000,
	 # 0b00000,
	 # 0b01110,
	 # 0b11111,
	 # 0b11111,
	 # 0b11111,
	 # 0b01110,
	 # 0b00000]

CH_HI_PAT = [
	 0b00100,
	 0b01110,
	 0b00000,
	 0b11111,
	 0b00000,
	 0b00000,
	 0b00000,
	 0b00000]

CH_LO_PAT = [
	 0b00000,
	 0b00000,
	 0b00000,
	 0b11111,
	 0b00000,
	 0b01110,
	 0b00100,
	 0b00000]

CH_HILO_PAT = [
	 0b00100,
	 0b01110,
	 0b00000,
	 0b11111,
	 0b00000,
	 0b01110,
	 0b00100,
	 0b00000]
	 

CH_DN_PAT = [
	 0b00000,
	 0b00000,
	 0b00000,
	 0b00000,
	 0b10001,
	 0b01010,
	 0b00100,
	 0b00000]
	 

CH_DOTS_PAT = [
	 0b00000,
	 0b00000,
	 0b00000,
	 0b00000,
	 0b00000,
	 0b00000,
	 0b10101,
	 0b00000]

CH_MA_PAT = [
	 0b11011,
	 0b10101,
	 0b10001,
	 0b00000,
	 0b00100,
	 0b01010,
	 0b11111,
	 0b10001]

CH_MW_PAT = [
	 0b11011,
	 0b10101,
	 0b10001,
	 0b00000,
	 0b10001,
	 0b10101,
	 0b10101,
	 0b11011]

CH_MV_PAT = [
	 0b11011,
	 0b10101,
	 0b10001,
	 0b00000,
	 0b10001,
	 0b10001,
	 0b01010,
	 0b00100]


lcd.create_char(CH_HI,CH_HI_PAT)
lcd.create_char(CH_LO,CH_LO_PAT)
lcd.create_char(CH_HILO,CH_HILO_PAT)
lcd.create_char(CH_DN,CH_DN_PAT)
lcd.create_char(CH_DOTS,CH_DOTS_PAT)
lcd.create_char(CH_MA,CH_MA_PAT)
lcd.create_char(CH_MW,CH_MW_PAT)
lcd.create_char(CH_MV,CH_MV_PAT)

EMPTYLINE = ' '.ljust(40)
Screen = [EMPTYLINE,EMPTYLINE] # shadow screen


def ClearLCD():
	lcd.clear()
	Screen = [EMPTYLINE,EMPTYLINE]
	return None
	
def LCDBacklight(TurnOn = True):
	backlight.value = TurnOn
	return None
	
def WriteLCD(col,row,txt,always = True):
	"""
		writes a text at given column and row
		The text is also written into a shadow Screen variable
		if the parameter "always" is not set, the text is first compared
		with the content of the shadow screen at that position and if 
		the text matches, nothing is written to the LCD. This avoids
		sending redundant text to the LCD (which is very slow) 
	"""
	Skip = False
	if not always:
		if Screen[row][col:col+len(txt)] == txt:
			Skip = True
	if not Skip:
		lcd.cursor_position(col,row)
		for c in txt:
			lcd._write8(ord(c),True)
		Screen[row] = Screen[row][:col]+txt+Screen[row][col+len(txt):]
	return None




def ShowCursor(col,row):
	lcd.cursor =True
	lcd.blink = True
	lcd.cursor_position(col,row)
	return None
	
def HideCursor():
	lcd.cursor =False
	lcd.blink = False
	return None
