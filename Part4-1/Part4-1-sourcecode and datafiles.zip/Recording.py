#!/usr/bin/env python3
#MIT License
#
#Copyright (c) 2019 TheHWcave
#
#Permission is hereby granted, free of charge, to any person obtaining a copy
#of this software and associated documentation files (the "Software"), to deal
#in the Software without restriction, including without limitation the rights
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#copies of the Software, and to permit persons to whom the Software is
#furnished to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
#SOFTWARE.
#

import os
import copy
from CommonDefs import *
#from LCDpanel import *
#from Buttons import ScanButtons, BUTTON1, BUTTON2, BUTTON3, BUTTON4, NO_EVENT,SHORT_PRESS, LONG_PRESS
from time import sleep,perf_counter,localtime,strftime
from Display import Display
from Measure import Measure


class Recording:
	"""
		handles recording of values in a CSV file format
	"""

	__disp	    = None 
	__data		= None
	__Recording = False
	__RecFile   = None

	__RECTIME	= (0,0,1.0,2.0,5.0,10.0,30.0,60.0,300.0)
	
	__LastTime	   = 0
	
	
	__OldSample    = -1

	__Now_tvapces  = []
	__Last_tvapces = []
	__Old_tvapces  = []
	__TIMEVAL = 0
	__VOLTVAL = 1
	__AMPSVAL = 2
	__PWRVAL  = 3
	__CAPVAL  = 4
	__ENVAL   = 5
	__SMPVAL  = 6

	def __GetValues(self):
		"""
			internal function to return the actual measurements in a list
		"""
		return(self.__data.GetRunning(),
			   self.__data.GetVolts(),
			   self.__data.GetCurrent(),
			   self.__data.GetPower(),
			   self.__data.GetCapacity(),
			   self.__data.GetEnergy(),
			   self.__data.GetSamples())
				   
	def SetRecording(self,TurnOn):
		"""
			If the parameter is true, starts a new recording if it 
			wasn't on or closes the previous recording first and then 
			starts a new one.
			If the parameter is false, any ongoing recording is stopped 
			and the recording file is closed 
			
			The recording filename is unique and consists of a date and 
			time stamp. The format is a CSV Comma-Separated-Values
			with a header line
		"""
		if TurnOn:
			if self.__Recording:
				self.__RecFile.close() # close previous recording
			fname = HOMEDIR+'Rec/REC_'+strftime('%Y%m%d%H%M%S',localtime())+'.csv'
			self.__RecFile = open(fname,'w')
			self.__RecFile.write('Time[S],Volts[V], Current[A],Power[W],Capacity[Ah],Energy[Wh]')
			if self.__data.GetRecOpt() == REC_CHANGES:
				self.__RecFile.write(',Samples[#]')
			self.__RecFile.write('\n')
			self.__Recording = True
			self.__disp.SetRecState(True)
			self.__Old_tvapces = self.__GetValues()
		else:
			if self.__Recording:
				self.__RecFile.close() # close recording
				self.__Recording = False
				self.__disp.SetRecState(False)
		return None

	
		
	def DoRecording(self, now):
		"""
			called in every main loop if recording 
			there are three main modes of recording
			
			REC_FAST creates a CSV line with the "now" data at every call
			
			REC_CHANGES compares the "now" volts and amps values with an old value and only if they differ 
			by more than a threshold, it does one or two CSV lines
			
			   OL  N                    O    L    N         O         L    N
			   *                        *    *              *    *    *
			       *                              *                        *
			   x   +1                   x    +1   +2        x    +1   +2   +3
			  REC_Changes keeps three samples: OLD, LAST and NOW
			  NOW is the present sample, LAST is the sample just before NOW, and OLD is the sample 
			  that had the same value as NOW in the past. 
			- if the sample difference between OLD and NOW is 1, it creates just one CSV line (NOW)
			  if the sample difference is greater, it creates two: producing an extra line with LAST
			  followed by NOW. This prevents graphs of the recorded data showing
			  very confusing and misleading slopes when, in reality, there should be a spike.
			 
			REC_xxx (any other): compares the difference in elapsed run time between "now" and the last time
			a CSV line was produced, and if a threshold is exceeded creates a new CSV line with the now data. 
		"""
		def AddCSVLine(tvapces,o):
			"""
				write a line into the CSV file
			"""
			self.__RecFile.write(self.__disp.Running2String(tvapces[self.__TIMEVAL],False))
			self.__RecFile.write(','+self.__disp.Volts2String(tvapces[self.__VOLTVAL],False))
			self.__RecFile.write(','+self.__disp.Current2String(tvapces[self.__AMPSVAL],False))
			self.__RecFile.write(','+self.__disp.Power2String(tvapces[self.__PWRVAL],False))
			self.__RecFile.write(','+self.__disp.Capacity2String(tvapces[self.__CAPVAL],False))
			self.__RecFile.write(','+self.__disp.Energy2String(tvapces[self.__ENVAL],False))
			if o == REC_CHANGES:
				self.__RecFile.write(','+str(tvapces[self.__SMPVAL]))
			self.__RecFile.write('\n')
			return None
			
		if self.__Recording:
			self.__Now_tvapces = self.__GetValues()
			opt    = self.__data.GetRecOpt()
			record_it = False
			if  opt == REC_CHANGES:
				if (abs(self.__Old_tvapces[self.__VOLTVAL]- self.__Now_tvapces[self.__VOLTVAL]) > 0.010 or
					abs(self.__Old_tvapces[self.__AMPSVAL]- self.__Now_tvapces[self.__AMPSVAL]) > 0.001):
					if abs(self.__Old_tvapces[self.__SMPVAL]- self.__Now_tvapces[self.__SMPVAL]) > 1:
						AddCSVLine(self.__Last_tvapces,opt)
					self.__Old_tvapces = copy.deepcopy(self.__Now_tvapces)
					record_it = True
			elif opt == REC_FAST:
				record_it = True
			else:
				if now - self.__LastTime >= self.__RECTIME[opt]:
					record_it = True
					self.__LastTime = now
			if record_it:
				AddCSVLine(self.__Now_tvapces,opt)
			self.__Last_tvapces = copy.deepcopy(self.__Now_tvapces)
		return None
		
	
	def DoSnapshot(self):
		"""
			Appends a line to SNAPSHOTS.TXT containing all available data and a timestamp
			if the file doesn't exist it is created. The file format is actually CSV, so it can be 
			imported into a spreadsheet if needed. 
		"""
		fname = HOMEDIR+'Rec/SNAPSHOTS.TXT'
		write_header = not os.path.exists(fname)
		with open(HOMEDIR+'Rec/SNAPSHOTS.TXT','a') as snap:
			if write_header:
				snap.write('Timestamp,Runtime[S],Volts[V],Amps[A},Power[W],Capacity[Ah],Energy[Wh],'
							'HiVolts[V],AvVolts[V],LoVolts[V],'
							'HiAmps[A],AvAmps[A],LoAmps[A],'
							'HiPower[W],AvPower[W],LoPower[W],'
							'LoadVolts[V],ShuntVolts[mV],INAPWR[W]\n')
			snap.write(strftime('%Y%m%d%H%M%S',localtime()))
			snap.write(','+self.__disp.Running2String(self.__data.GetRunning(),False))
			snap.write(','+self.__disp.Volts2String(self.__data.GetVolts(),False))
			snap.write(','+self.__disp.Current2String(self.__data.GetCurrent(),False))
			snap.write(','+self.__disp.Power2String(self.__data.GetPower(),False))
			snap.write(','+self.__disp.Capacity2String(self.__data.GetCapacity(),False))
			snap.write(','+self.__disp.Energy2String(self.__data.GetEnergy(),False))
			snap.write(','+self.__disp.Volts2String(self.__data.GetHiVolts(),False))
			snap.write(','+self.__disp.Volts2String(self.__data.GetAvVolts(),False))
			snap.write(','+self.__disp.Volts2String(self.__data.GetLoVolts(),False))
			snap.write(','+self.__disp.Current2String(self.__data.GetHiCurrent(),False))
			snap.write(','+self.__disp.Current2String(self.__data.GetAvCurrent(),False))
			snap.write(','+self.__disp.Current2String(self.__data.GetLoCurrent(),False))
			snap.write(','+self.__disp.Power2String(self.__data.GetHiPower(),False))
			snap.write(','+self.__disp.Power2String(self.__data.GetAvPower(),False))
			snap.write(','+self.__disp.Power2String(self.__data.GetLoPower(),False))
			snap.write(','+self.__disp.Volts2String(self.__data.GetLoadVolts(),False))
			snap.write(','+'{:+7.2f}'.format(1000*self.__data.GetShuntVolts()))
			snap.write(','+self.__disp.Power2String(self.__data.GetINAPower(),False))
			snap.write('\n')
		return None
			
			
	def __init__(self, disp, data):
		""" setup the class to have access to measurement data to get the 
		    to recorded values from and to the display to tell it about
		    the recording status and use the available string conversion
		    routines 
		"""

		self.__disp      = disp
		self.__data		 = data
		self.__Recording = False
		self.__RecLast   = 0
		 
		self.__disp.SetRecObject(self) # give display access to recording
		
