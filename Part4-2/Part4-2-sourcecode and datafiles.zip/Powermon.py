#!/usr/bin/env python3
#MIT License
#
#Copyright (c) 2019 TheHWcave
#
#Permission is hereby granted, free of charge, to any person obtaining a copy
#of this software and associated documentation files (the "Software"), to deal
#in the Software without restriction, including without limitation the rights
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#copies of the Software, and to permit persons to whom the Software is
#furnished to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
#SOFTWARE.
#
from time import sleep,perf_counter
import os,sys,traceback

import board
import digitalio
from CommonDefs import *
from LCDpanel import *
from Buttons import ScanButtons, BUTTON1, BUTTON2, BUTTON3, BUTTON4, NO_EVENT,SHORT_PRESS, LONG_PRESS
from INA219 import INA219
from Measure import Measure
from Display import Display
from Menu import Menu
from Edit import Edit
from Show import Show
from Cal import Cal
from Recording import Recording
from Relay import Relay


Overload = digitalio.DigitalInOut(board.D16)
Overload.direction = digitalio.Direction.OUTPUT



MAIN = Menu(['Run','Limits'+DOTS,'Relay'+DOTS,'Record'+DOTS,'Setup'+DOTS,'Off'+DOTS,'Calib'+DOTS])
MAIN_RUN   = 0
MAIN_LIMITS= 1
MAIN_RELAY = 2
MAIN_RECORD= 3
MAIN_SETUP = 4
MAIN_OFF   = 5
MAIN_CALIB = 6
Main_Sel   = MAIN_RUN

showMenu   = True
isTurnedOff= False
hasCrashed = False


LIMITS = Menu(['Show','Clear','Load','Save','HiVolt'+DOTS,'LoVolt'+DOTS,'HiAmps'+DOTS,'LoAmps'+DOTS,'Time[s]'+DOTS,'C[mAh]'+DOTS,'E[mWh]'+DOTS])
LIMITS_SHOW	   = 0
LIMITS_CLEAR   = 1
LIMITS_LOAD    = 2
LIMITS_SAVE    = 3
LIMITS_HIVOLT  = 4
LIMITS_LOVOLT  = 5
LIMITS_HIAMPS  = 6
LIMITS_LOAMPS  = 7
LIMITS_TIME    = 8
LIMITS_CAP     = 9
LIMITS_ENE	   = 10
Limits_Sel     = LIMITS_SHOW

SETUP   = Menu(['Show','Default','Volts'+DOTS,'RecOpt'+DOTS,'ARec'+DOTS,'Sampls'+DOTS,'Shunts'+DOTS])
SETUP_SHOW     = 0
SETUP_DEFAULT  = 1
SETUP_VOLTS    = 2
SETUP_RECOPT   = 3
SETUP_AUTOREC  = 4
SETUP_SAMOPT   = 5
SETUP_SHUNTS   = 6
SETUP_Sel      = SETUP_SHOW

CALIB  = Menu(['Show','Volts'+DOTS,'Cur A'+DOTS,'Cur B'+DOTS,'Cur C'+DOTS,'Cur D'+DOTS])
CALIB_SHOW     = 0
CALIB_VOLTS    = 1
CALIB_CUR_A	   = 2
CALIB_CUR_B    = 3
CALIB_CUR_C	   = 4
CALIB_CUR_D	   = 5
CALIB_Sel      = CALIB_SHOW

SHOWERR   = Show()
SHOWLIM   = Show()
SHOWSETUP = Show()
SHOWCAL	  = Show()

SET_VOLT   = Edit(Min=0.0,Max=20.0,CanBeNeg=False,UseFloat=True) 
SET_AMPS   = Edit(Min=-99.999,Max=99.999,CanBeNeg=True,UseFloat=True) 
SET_TCE    = Edit(Min=0,Max=99999,CanBeNeg=False,UseFloat=False) 
SET_RECINT = Edit(Min=0.1,Max=99.999,CanBeNeg=False,UseFloat=True) 

ONOFF      = Menu()
ONOFF_OFF  = 0
ONOFF_ON   = 1

RECOPT   = ['RecChg','RecFast','Rec 1s','Rec 2s','Rec 5s','Rec10s','Rec30s','Rec1min','Rec5min']
RECMENU	 = Menu(RECOPT)

SAMOPT   = ['x1','x2','x4','x8','x16','x32','x64','x128']
SAMMENU	 = Menu(SAMOPT)


ErrPrompt = ''



def EvH_Main(Ev):
	global EvH,EvH_Par1
	sel = MAIN.GetSelected()
	res = MAIN.Show(Ev,'Select:',sel)
	if res == MENU_ENTER:
		sel = MAIN.GetSelected()
		#ClearLCD()
		HideCursor()
		if sel == MAIN_RUN:
			EvH = EvH_Run
		elif sel == MAIN_LIMITS:
			EvH = EvH_Limits
		elif sel == MAIN_RELAY:
			ONOFF.SetOptionList(['RelayOff','Relay ON'])
			EvH = EvH_Relay
		elif sel == MAIN_RECORD:
			ONOFF.SetOptionList(['Rec Off','Rec ON'])
			EvH = EvH_Rec
		elif sel == MAIN_SETUP:
			EvH = EvH_Setup
		elif sel == MAIN_OFF:
			ONOFF.SetOptionList(['turn Off','stay ON'])
			EvH = EvH_Off
		elif sel == MAIN_CALIB:
			EvH = EvH_Calib
	elif res == MENU_TOP:
		HideCursor()
		EvH = EvH_Run
	return None

def EvH_Run(Ev):
	global EvH,EvH_Par1
	res = disp.RunDisplay(Ev)
	if res != MENU_PENDING:
		#ClearLCD()
		HideCursor()
		EvH = EvH_Main
	return None

def EvH_ShowErr(Ev):
	global EvH,EvH_Par1
	res = SHOWERR.ShowVal(Ev)
	if res != MENU_PENDING:
		#ClearLCD()
		HideCursor()
		EvH = EvH_Par1
	return None

def EvH_Limits(Ev):
	global EvH,EvH_Par1
	sel = LIMITS.GetSelected()
	res = LIMITS.Show(Ev,'Select:',sel)
	if res == MENU_ENTER:
		#ClearLCD()
		HideCursor()
		sel = LIMITS.GetSelected()
		if sel == LIMITS_SHOW:
			valist = []
			valist.append(disp.Lim_HiVoltStr())
			valist.append(disp.Lim_LoVoltStr())
			valist.append(disp.Lim_HiAmpsStr())
			valist.append(disp.Lim_LoAmpsStr())
			valist.append(disp.Lim_TimeStr())
			valist.append(disp.Lim_CAPStr())
			valist.append(disp.Lim_ENEStr())
			SHOWLIM.SetValueList(valist)
			EvH = EvH_ShowLims
		elif sel == LIMITS_CLEAR: data.ClearLimits()
		elif sel == LIMITS_LOAD:
			success = data.LoadLimits()
			if not success:
				SHOWERR.SetValueList(['Err:Load',' failed'])
				EvH_Par1 = EvH_Limits
				EvH = EvH_ShowErr
		elif sel == LIMITS_SAVE: data.SaveLimits()
		elif sel == LIMITS_HIVOLT: 
			EvH_Par1 = True
			EvH = EvH_Volts
		elif sel == LIMITS_LOVOLT: 
			EvH_Par1 = False
			EvH = EvH_Volts
		elif sel == LIMITS_HIAMPS: 
			EvH_Par1 = True
			EvH = EvH_Amps
		elif sel == LIMITS_LOAMPS: 
			EvH_Par1 = False
			EvH = EvH_Amps
		elif sel == LIMITS_TIME: 
			EvH_Par1 = LIM_TIME
			EvH = EvH_TCE
		elif sel == LIMITS_CAP: 
			EvH_Par1 = LIM_CAP
			EvH = EvH_TCE
		elif sel == LIMITS_ENE: 
			EvH_Par1 = LIM_ENE
			EvH = EvH_TCE
		else:
			EvH = EvH_Main 
	elif res == MENU_BACK:
		#ClearLCD()
		HideCursor()
		EvH = EvH_Main
	elif res == MENU_TOP:
		HideCursor()
		EvH = EvH_Run
	return None
	
def EvH_Setup(Ev):
	global EvH,EvH_Par1
	sel = SETUP.GetSelected()
	res = SETUP.Show(Ev,'Select:',sel)
	if res == MENU_ENTER:
		#ClearLCD()
		HideCursor()
		sel = SETUP.GetSelected()
		if sel == SETUP_SHOW:
			valist = []
			if data.GetLoadVoltsOpt():
				valist.append('V=load')
			else:
				valist.append('V=supp')
			valist.append(data.GetShuntName())
			valist.append(RECOPT[data.GetRecOpt()])
			if data.GetAutoRec():
				valist.append('ARec=Y')
			else:
				valist.append('ARec=No')
			valist.append(disp.Field2Str()[0])
			valist.append(disp.Field2Str()[1])
			valist.append(SAMOPT[data.GetSampling()])
			SHOWSETUP.SetValueList(valist)
			EvH = EvH_ShowSetup
		elif sel == SETUP_DEFAULT: 
			data.SetLoadVoltsOpt(True)
			sl = data.ReadShunts()
			ina.Setup(sl[0][SHUNTRES],sl[0][CALCUR],data.GetVoltCalData())
			data.SetShunt(0)
			data.SetRecOpt(REC_1S)
			data.SetRunFields([0,0])
			data.SetSampling(SAMPLES_8)
			data.SetAutoRec(False)
			ina.SetADCSampling(data.GetSampling())
		elif sel == SETUP_RECOPT:
			EvH = EvH_RecOpt
		elif sel == SETUP_AUTOREC:
			ONOFF.SetOptionList(['ARec=No','ARec=Y'])
			EvH = EvH_AutoRec
		elif sel == SETUP_SAMOPT:
			EvH = EvH_SamOpt
		elif sel == SETUP_SHUNTS:
			EvH = EvH_Shunts
		elif sel == SETUP_VOLTS: 
			ONOFF.SetOptionList(['use Supp','use Load'])
			EvH = EvH_VSource
		else:
			EvH = EvH_Main 
	elif res == MENU_BACK:
		#ClearLCD()
		HideCursor()
		EvH = EvH_Main
	elif res == MENU_TOP:
		HideCursor()
		EvH = EvH_Run
	return None
	
def EvH_Calib(Ev):
	global EvH,EvH_Par1
	sel = CALIB.GetSelected()
	res = CALIB.Show(Ev,'Select:',sel)
	if res == MENU_ENTER:
		#ClearLCD()
		HideCursor()
		sel = CALIB.GetSelected()
		if sel == CALIB_SHOW:
			valist = []
			cd = data.GetVoltCalData()
			ch = 'V'
			valist.append(ch+disp.CalVal2Str(cd[BVSLOPE]))
			valist.append(' '+disp.CalVal2Str(cd[BVINTER]))
			ch = 'A'
			cd = data.GetCurCalData(data.GetShunt())
			for r in cd:
				valist.append(ch+disp.CalVal2Str(r[CURSLOPE]))
				valist.append(' '+disp.CalVal2Str(r[CURINTER]))
				ch = chr(ord(ch)+1)
			SHOWCAL.SetValueList(valist)
			EvH = EvH_ShowCal
		elif sel == CALIB_VOLTS: 
			EvH_Par1 = -1
			EvH = EvH_DoCal
		elif sel == CALIB_CUR_A:
			EvH_Par1 = SHUNT_40MV
			EvH = EvH_DoCal
		elif sel == CALIB_CUR_B:
			EvH_Par1 = SHUNT_80MV
			EvH = EvH_DoCal
		elif sel == CALIB_CUR_C:
			EvH_Par1 = SHUNT_160MV
			EvH = EvH_DoCal
		elif sel == CALIB_CUR_D:
			EvH_Par1 = SHUNT_320MV
			EvH = EvH_DoCal
		else:
			EvH = EvH_Main 
	elif res == MENU_BACK:
		#ClearLCD()
		HideCursor()
		EvH = EvH_Main
	elif res == MENU_TOP:
		HideCursor()
		EvH = EvH_Run
	return None

def EvH_VSource(Ev):
	global EvH,EvH_Par1
	if data.GetLoadVoltsOpt():
		sel = ONOFF_ON
	else:
		sel = ONOFF_OFF
	res = ONOFF.Show(Ev,'Select:',sel)
	if res == MENU_ENTER:
		sel = ONOFF.GetSelected()
		if sel == ONOFF_OFF:
			data.SetLoadVoltsOpt(False)
		else:
			data.SetLoadVoltsOpt(True)
		HideCursor()
		EvH = EvH_Setup
	if res == MENU_BACK:
		#ClearLCD()
		HideCursor()
		EvH = EvH_Setup
	elif res == MENU_TOP:
		HideCursor()
		EvH = EvH_Run
	return None

	
def EvH_Relay(Ev):
	global EvH,EvH_Par1
	if relay.GetRelay():
		sel = ONOFF_ON
	else:
		sel = ONOFF_OFF
	res = ONOFF.Show(Ev,'Select:',sel)
	if res == MENU_ENTER:
		sel = ONOFF.GetSelected()
		if sel == ONOFF_OFF:
			relay.SetRelay(False)
		else:
			relay.SetRelay(True)
		HideCursor()
		EvH = EvH_Main
	if res == MENU_BACK:
		#ClearLCD()
		HideCursor()
		EvH = EvH_Main
	elif res == MENU_TOP:
		HideCursor()
		EvH = EvH_Run
	return None
	
def EvH_Rec(Ev):
	global EvH,EvH_Par1
	if disp.GetRecState():
		sel = ONOFF_ON
	else:
		sel = ONOFF_OFF
	res = ONOFF.Show(Ev,'Select:',sel)
	if res == MENU_ENTER:
		sel = ONOFF.GetSelected()
		if sel == ONOFF_OFF:
			record.SetRecording(False)
		else:
			record.SetRecording(True)
		HideCursor()
		EvH = EvH_Main
	if res == MENU_BACK:
		#ClearLCD()
		HideCursor()
		EvH = EvH_Main
	elif res == MENU_TOP:
		HideCursor()
		EvH = EvH_Run
	return None
	
def EvH_Off(Ev):
	global EvH,EvH_Par1, isTurnedOff
	res = ONOFF.Show(Ev,'Select:',True)
	if res == MENU_ENTER:
		sel = ONOFF.GetSelected()
		if sel == ONOFF_OFF:
			isTurnedOff = True 
	if res == MENU_BACK:
		ClearLCD()
		HideCursor()
		EvH = EvH_Main
	elif res == MENU_TOP:
		HideCursor()
		EvH = EvH_Run
	return None
	
def EvH_Shunts(Ev):
	global EvH,EvH_Par1
	sel = data.GetShunt()
	res = SHUNTS.Show(Ev,'Select:',sel)
	if res == MENU_ENTER:
		#ClearLCD()
		HideCursor()
		sel = SHUNTS.GetSelected()
		sl = data.ReadShunts()
		bvdata = data.GetVoltCalData()
		ina.Setup(sl[sel][SHUNTRES],sl[sel][CALCUR],bvdata)
		data.SetShunt(sel)
		EvH = EvH_Setup 
	elif res == MENU_BACK:
		#ClearLCD()
		HideCursor()
		EvH = EvH_Setup
	elif res == MENU_TOP:
		HideCursor()
		EvH = EvH_Run
	return None
	
def EvH_ShowLims(Ev):
	global EvH,EvH_Par1,ErrPrompt
	res = SHOWLIM.ShowVal(Ev)
	if res == MENU_BACK:
		#ClearLCD()
		HideCursor()
		EvH = EvH_Limits
	elif res == MENU_TOP:
		HideCursor()
		EvH = EvH_Run
	return None
	
def EvH_ShowSetup(Ev):
	global EvH,EvH_Par1,ErrPrompt
	res = SHOWSETUP.ShowVal(Ev)
	if res == MENU_BACK:
		#ClearLCD()
		HideCursor()
		EvH = EvH_Setup
	elif res == MENU_TOP:
		HideCursor()
		EvH = EvH_Run
	return None
	
def EvH_ShowCal(Ev):
	global EvH,EvH_Par1,ErrPrompt
	res = SHOWCAL.ShowVal(Ev)
	if res == MENU_BACK:
		#ClearLCD()
		HideCursor()
		EvH = EvH_Calib
	elif res == MENU_TOP:
		HideCursor()
		EvH = EvH_Run
	return None
	
	
def EvH_Volts(Ev):
	global EvH,EvH_Par1,ErrPrompt
	Err = False
	if ErrPrompt != '': 
		prompt = ErrPrompt
		ErrPrompt = ''
	else:
		prompt = 'Edit:'
	sel = data.GetLimit(LIM_VOLTS)
	if EvH_Par1:
		cuval=[sel[LIM_MAXVAL],(sel[LIM_CHECK] == CHK_MAX) or (sel[LIM_CHECK] == CHK_ALL)]
	else:
		cuval=[sel[LIM_MINVAL],(sel[LIM_CHECK] == CHK_MIN) or (sel[LIM_CHECK] == CHK_ALL)]
	res = SET_VOLT.EditVal(Ev,prompt,cuval)
	if res == MENU_ENTER:
		#ClearLCD()
		HideCursor()
		sel = SET_VOLT.GetSelected()
		Err = data.Set_and_Validate_Limit(LIM_VOLTS,hi=EvH_Par1, newval = sel[RETVAL_VAL], newact = sel[RETVAL_ACT])
		if Err: 
			ErrPrompt = 'Max>Min!'
		else:
			ErrPrompt = ''
			EvH = EvH_Limits
	elif res == MENU_BACK:
		EvH = EvH_Limits
	elif res == MENU_TOP:
		HideCursor()
		EvH = EvH_Run
	return None	
	
def EvH_Amps(Ev):
	global EvH,EvH_Par1,ErrPrompt
	Err = False
	if ErrPrompt != '': 
		prompt = ErrPrompt
		ErrPrompt = ''
	else:
		prompt = 'Edit:'
	sel = data.GetLimit(LIM_AMPS)
	if EvH_Par1:
		cuval=[sel[LIM_MAXVAL],(sel[LIM_CHECK] == CHK_MAX) or (sel[LIM_CHECK] == CHK_ALL)]
	else:
		cuval=[sel[LIM_MINVAL],(sel[LIM_CHECK] == CHK_MIN) or (sel[LIM_CHECK] == CHK_ALL)]
	res = SET_AMPS.EditVal(Ev,prompt,cuval)
	if res == MENU_ENTER:
		#ClearLCD()
		HideCursor()
		sel = SET_AMPS.GetSelected()
		Err = data.Set_and_Validate_Limit(LIM_AMPS,hi=EvH_Par1, newval = sel[RETVAL_VAL], newact = sel[RETVAL_ACT])
		if Err: 
			ErrPrompt = 'Max>Min!'
		else:
			ErrPrompt = ''
			EvH = EvH_Limits
	elif res == MENU_BACK:
		EvH = EvH_Limits
	elif res == MENU_TOP:
		HideCursor()
		EvH = EvH_Run
	return None	
	
def EvH_TCE(Ev):
	global EvH,EvH_Par1,ErrPrompt
	Err = False
	if ErrPrompt != '': 
		prompt = ErrPrompt
		ErrPrompt = ''
	else:
		prompt = 'Edit:'
	sel = data.GetLimit(EvH_Par1)
	cuval=[sel[LIM_MAXVAL],(sel[LIM_CHECK] == CHK_MAX) or (sel[LIM_CHECK] == CHK_ALL)]
	res = SET_TCE.EditVal(Ev,prompt,cuval)
	if res == MENU_ENTER:
		#ClearLCD()
		HideCursor()
		sel = SET_TCE.GetSelected()
		Err = data.Set_and_Validate_Limit(EvH_Par1,hi = True, newval = sel[RETVAL_VAL], newact = sel[RETVAL_ACT])
		if Err: 
			ErrPrompt = 'Max>Min!'
		else:
			ErrPrompt = ''
			EvH = EvH_Limits
	elif res == MENU_BACK:
		EvH = EvH_Limits
	elif res == MENU_TOP:
		HideCursor()
		EvH = EvH_Run
	return None	

def EvH_RecOpt(Ev):
	global EvH,EvH_Par1,ErrPrompt
	sel = data.GetRecOpt()
	res = RECMENU.Show(Ev,'Select:',sel)
	if res == MENU_ENTER:
		#ClearLCD()
		HideCursor()
		sel = RECMENU.GetSelected()
		data.SetRecOpt(sel)
		EvH = EvH_Setup
	elif res == MENU_BACK:
		EvH = EvH_Setup
	elif res == MENU_TOP:
		HideCursor()
		EvH = EvH_Run
	return None	


def EvH_AutoRec(Ev):
	global EvH,EvH_Par1
	if data.GetAutoRec():
		sel = ONOFF_ON
	else:
		sel = ONOFF_OFF
	res = ONOFF.Show(Ev,'Select:',sel)
	if res == MENU_ENTER:
		sel = ONOFF.GetSelected()
		if sel == ONOFF_OFF:
			data.SetAutoRec(False)
		else:
			data.SetAutoRec(True)
		HideCursor()
		EvH = EvH_Setup
	if res == MENU_BACK:
		#ClearLCD()
		HideCursor()
		EvH = EvH_Setup
	elif res == MENU_TOP:
		HideCursor()
		EvH = EvH_Run
	return None
	
def EvH_SamOpt(Ev):
	global EvH,EvH_Par1,ErrPrompt
	sel = data.GetSampling()
	res = SAMMENU.Show(Ev,'Select:',sel)
	if res == MENU_ENTER:
		#ClearLCD()
		HideCursor()
		sel = SAMMENU.GetSelected()
		data.SetSampling(sel)
		ina.SetADCSampling(data.GetSampling())
		EvH = EvH_Setup
	elif res == MENU_BACK:
		EvH = EvH_Setup
	elif res == MENU_TOP:
		HideCursor()
		EvH = EvH_Run
	return None	

def EvH_DoCal(Ev):
	global EvH,EvH_Par1
	res = cal.DoCal(Ev,EvH_Par1)
	if res == MENU_ENTER:
		#ClearLCD()
		HideCursor()
		EvH = EvH_Calib
	elif res == MENU_BACK:
		#ClearLCD()
		HideCursor()
		EvH = EvH_Calib
	elif res == MENU_TOP:
		HideCursor()
		EvH = EvH_Run
	return None
	
		
if __name__ == "__main__":

	try:
	
		
		
	
		
		data = Measure()
		data.ClearAllMeasurements()
		data.LoadSetup()
		
		sl = data.ReadShunts()
		slv = []
		for s in sl:
			slv.append(str(s[SHUNTNAM]))
		SHUNTS = Menu(slv)
		
		shsel = data.GetShunt()
		if shsel >= len(slv):
			print('saved shunt selection out of range, default used')
			shsel = 0
			data.SetShunt(shsel)
		ina = INA219(sl[shsel][SHUNTRES],sl[shsel][CALCUR],data.GetVoltCalData(),SAMPLES_2)
		ina.SetRange(AUTO_RANGE,SHUNT_320MV)
		ina.SetADCSampling(data.GetSampling())
		
		relay = Relay(board.D17)
		
		disp = Display(data,ina,relay)
		
		record = Recording(disp,data)
		cal    = Cal(data,ina,disp)
		
	
		bv_overflow = False
		sv_overflow = False
		
		ClearLCD()
	
		relay.value = False
		oldvapso = (INVALID,INVALID,INVALID,INVALID,False)
		
		
		relay.SetRelay(False)
		
		
		"""
			fake a SELECT press to get from Run Menu into the 
			run display directly at startup
		"""
		EvH = EvH_Main
		EvH_Par1 = 0 
		Ev = (BUTTON2,SHORT_PRESS)
		EvH(Ev)
		
		LOOPS_PER_SECOND = 75
		LOOPTIME = 1.0/LOOPS_PER_SECOND
		DISP_PER_SECOND = 3
		LOOPS_PER_DISP = LOOPS_PER_SECOND/DISP_PER_SECOND
		
		cnt =0
		while not isTurnedOff: 
			cnt = cnt + 1
			if cnt >= LOOPS_PER_SECOND:cnt = 0
				
			now = perf_counter()
			
			newvapso = ina.Read_INA()
			Lim = data.NewData(newvapso)
			if Lim:
				relay.SetRelay(False)
			Overload.value = newvapso[OVER]

			record.DoRecording(now)
			
			Ev   = ScanButtons()
			
			if Ev != (BUTTON1,NO_EVENT) or (cnt % LOOPS_PER_DISP == 0):
				EvH(Ev)
			
			# if Ev != (BUTTON1,NO_EVENT):
				# old_EvH = EvH
				# print(Ev,EvH)
				# EvH(Ev)
				# if old_EvH != EvH:
					# print('x',EvH)
					# EvH((BUTTON1,NO_EVENT))
			# elif (EvH == EvH_Run) and (cnt % LOOPS_PER_DISP == 0):
				# EvH(Ev)
			
			if (cnt % LOOPS_PER_DISP == 0): 
				disp.Tick()
			
			

			
			
			elapsed = perf_counter() - now
			if elapsed < LOOPTIME: 
				sleep(LOOPTIME-elapsed)
		#end while
	except KeyboardInterrupt:
		print('...exiting')
	except: 
		print(traceback.print_exc())
		ClearLCD()
		WriteLCD(0,0,'error'+str(sys.exc_info()[0])[6:])
		WriteLCD(0,1,str(sys.exc_info()[1]))
		hasCrashed = True
		
	#end try
	if hasCrashed:
		while not isTurnedOff:
			Ev = ScanButtons()
			isTurnedOff = (Ev == (BUTTON4,LONG_PRESS))
			sleep(0.1)
		os.system("sudo shutdown -h now")
	if isTurnedOff:
		record.SetRecording(False)
		os.system("sudo shutdown -h now")
#end if
