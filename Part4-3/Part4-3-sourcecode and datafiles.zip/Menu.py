#!/usr/bin/env python3
#MIT License
#
#Copyright (c) 2019 TheHWcave
#
#Permission is hereby granted, free of charge, to any person obtaining a copy
#of this software and associated documentation files (the "Software"), to deal
#in the Software without restriction, including without limitation the rights
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#copies of the Software, and to permit persons to whom the Software is
#furnished to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
#SOFTWARE.
#

from CommonDefs import *
from LCDpanel import *
from Buttons import ScanButtons, BUTTON1, BUTTON2, BUTTON3, BUTTON4, NO_EVENT,SHORT_PRESS, LONG_PRESS


class Menu:
	"""
		needs to be instantiated with a list of option (strings)
		shows the selected option behind the prompt on 1st row and
		the text PREV SEL NEXT BACK on second
		
		returns MENU_PENDING except as shown below:
		Handles the events
		  Button   press     
			1      short   : previous option, restart at top if needed
			1      long    : (not used)
			2      short   : select current option and return MENU_ENTER
			2      long    : (not used)
			3      short   : next option, restart down at 0 if needed
			3      long    : (not used)
			4      short   : return MENU_BACK and reset selected option 
			4      long	   : (not used)
			
	"""

	
	__oplist	= None


	__firstcall	= True
	__selval	= None
	__cursor	= None

	

	def GetSelected(self):	
		return self.__selval
	
	def SetOptionList(self,new_list):
		self.__oplist = new_list
		self.__firstcall = True
		self.__selval = 0
		self.__cursor = 0

	def Show(self,Ev,Prompt, Curval):
		res = MENU_PENDING
		if self.__firstcall:
			self.__selval = Curval
			WriteLCD(0,0,Prompt.ljust(8))
			WriteLCD(8,0,' '.ljust(8)) # clear option field to force 1st time LCD update
			WriteLCD(0,1,"PRV SEL NXT BACK")
			ShowCursor(8,0) 
			self.__firstcall = False
		WriteLCD(8,0,self.__oplist[self.__selval].ljust(8),False)
		ShowCursor(15,0)
		if Ev == (BUTTON1,SHORT_PRESS): # prev
			if self.__selval > 0:
				self.__selval = self.__selval -1
			else:
				self.__selval = len(self.__oplist)-1
		elif Ev == (BUTTON3,SHORT_PRESS): # next
			if self.__selval < len(self.__oplist)-1:
				self.__selval = self.__selval +1
			else:
				self.__selval = 0
		elif Ev == (BUTTON2,SHORT_PRESS): # select
			res = MENU_ENTER
		elif Ev == (BUTTON4,SHORT_PRESS): # back short press
			res = MENU_BACK
			self.__selval = Curval
		elif Ev == (BUTTON4,LONG_PRESS): # back long press
			res = MENU_TOP
			self.__selval = Curval
		if res != MENU_PENDING:
			self.__firstcall = True
		return res


	def __init__(self, optionlist = []):
		""" setup a menu of options
		
			  list = ['first ','second','third '] 
			
			
		"""

		
		self.__oplist = optionlist
	
		self.__firstcall = True
		self.__selval = 0
		self.__cursor = 0
		
