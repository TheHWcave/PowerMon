#!/usr/bin/env python3
#MIT License
#
#Copyright (c) 2019 TheHWcave
#
#Permission is hereby granted, free of charge, to any person obtaining a copy
#of this software and associated documentation files (the "Software"), to deal
#in the Software without restriction, including without limitation the rights
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#copies of the Software, and to permit persons to whom the Software is
#furnished to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
#SOFTWARE.
#
from time import sleep,perf_counter,localtime,strftime
import sys,json
from CommonDefs import *
import copy

class Measure:
	"""
		This class handles all the maths, statistics, limit tests and 
		other data related functions. It also reads and writes the files:
		
		SETUP.txt    contains the current configuration so it can be restored when restarted
		LIMITS.txt   can be used to save and reload limits 
		CALDATA.txt  contains a list of know shunt resistors and their calibration data
	"""
	
	__Overflow	= INVALID
	__LoadVolts	= INVALID
	__ShuntVolts= INVALID
	__Current	= INVALID
	__INAPower	= INVALID
	__INACurrent= INVALID
	__Power		= INVALID
	__Volts		= INVALID
	__Capacity	= INVALID
	__Energy	= INVALID
	__StartTime	= INVALID
	__Running	= INVALID
	__HiVolts	= INVALID
	__HiCurrent	= INVALID
	__HiPower	= INVALID
	__AvVolts	= INVALID
	__AvCurrent	= INVALID
	__AvPower	= INVALID
	__LoVolts	= INVALID
	__LoCurrent	= INVALID
	__LoPower	= INVALID
	__SumVolts	= INVALID
	__SumCurrent= INVALID
	__SumPower	= INVALID
	__Samples	= INVALID
	
	__UseLoadVolts = True
	__RecOpt       = 0
	__AutoRec	   = False
	__RunFields	   = [0,0]
	__SampRate	   = 0

	__Limits = [[CHK_OFF,0.0,0.0,False,False], # volts
				[CHK_OFF,0.0,0.0,False,False], # amps
				[CHK_OFF,0.0,0.0,False,False], # time
				[CHK_OFF,0.0,0.0,False,False], # mAh
				[CHK_OFF,0.0,0.0,False,False]] # mWh
				
	__ShuntList = []
	__ShuntSelected  = 0
	__ShuntVal = 0
	__BVCalData = []
	__SVCalData = []
	
	def ClearAllMeasurements(self):
		self.__StartTime 	= perf_counter()
		self.__Overflow 	= False
		self.__LoadVolts	= 0.0
		self.__ShuntVolts	= 0.0
		self.__Current		= 0.0
		self.__INAPower		= 0.0
		self.__INACurrent	= 0.0
		self.__Power		= 0.0
		self.__Volts		= 0.0
		self.__Capacity		= 0
		self.__Energy		= 0
		self.__Running		= 0.0
		self.__HiVolts		= -INVALID
		self.__HiCurrent	= -INVALID
		self.__HiPower		= -INVALID
		self.__AvVolts		= 0.0
		self.__AvCurrent	= 0.0
		self.__AvPower		= 0.0
		self.__LoVolts		= INVALID
		self.__LoCurrent	= INVALID
		self.__LoPower		= INVALID
		self.__SumVolts 	= 0.0
		self.__SumCurrent	= 0.0
		self.__SumPower		= 0.0
		self.__Samples		= 0
		self.ResetLimitsHit()
		return None
	
	

		
		
	def ReadShunts (self):
		return list(self.__ShuntList)
		
	def SetShunt(self,shunt):
		self.__ShuntSelected = shunt
		self.SaveSetup()
		return None
		
	def GetShunt(self):
		return self.__ShuntSelected
		
	def GetShuntName(self):
		return self.__ShuntList[self.__ShuntSelected][SHUNTNAM]
		
	def GetShuntNValue(self):
		return self.__ShuntList[self.__ShuntSelected][SHUNTRES]
		
	def GetShuntAValue(self):
		return self.__ShuntList[self.__ShuntSelected][SHUNTVAL]
	
	def SetShuntAValue(self, NewShuntValue):
		self.__ShuntList[self.__ShuntSelected][SHUNTVAL] = NewShuntValue
		return None
	
	def GetCurCalData(self,shunt=None):
		if shunt == None:
			shunt = self.__ShuntSelected
		return copy.deepcopy(self.__ShuntList[shunt])
		
	def GetBVoltCalData(self):
		return copy.deepcopy(self.__BVCalData)
		
	def GetSVoltCalData(self):
		return copy.deepcopy(self.__SVCalData)
	
	
	def UpdateCalData (self, calBvolt, calSvolt):
		self.__BVCalData = copy.deepcopy(calBvolt)
		self.__SVCalData = copy.deepcopy(calSvolt)
		fo = open(HOMEDIR+'CALDATA.TXT','w')
		fo.write(json.dumps(self.__BVCalData)+'\n')
		fo.write(json.dumps(self.__SVCalData)+'\n')
		for sle in self.__ShuntList:
			fo.write(json.dumps(sle)+'\n')
		fo.close()
		return None
	
	def SetLoadVoltsOpt(self,ok = True):
		self.__UseLoadVolts = ok
		self.SaveSetup()
		return None
		
	def GetLoadVoltsOpt(self):
		return self.__UseLoadVolts

	def SetRecOpt(self,opt):
		self.__RecOpt = opt
		self.SaveSetup()
		return None
		
	def GetAutoRec(self):
		return self.__AutoRec
		
	def SetAutoRec(self,turnon):
		self.__AutoRec = turnon
		self.SaveSetup()
		return None
		
	def GetRecOpt(self):
		return self.__RecOpt
		
	def SetRunFields(self,fields):
		self.__RunFields = fields
		self.SaveSetup()
		return None
		
	def GetRunFields(self):
		return self.__RunFields
	
	def SetSampling(self,sr):
		self.__SampRate = sr
		self.SaveSetup()
		return None
		
	def GetSampling(self):
		return self.__SampRate
		
	def SetLimit(self,Kind,Chk,Min,Max):
		self.__Limits[Kind] = [Chk,Min,Max,False,False]
		self.SaveSetup()
		return None
		
	def ResetLimitsHit(self):
		for lim in self.__Limits:
			lim[LIM_MINHIT] = False
			lim[LIM_MAXHIT] = False
		return None
		
	def GetLimit(self,Kind):
		return self.__Limits[Kind]
		
	def ClearLimits(self):
		self.SetLimit(LIM_VOLTS,CHK_OFF,0.0,0.0)
		self.SetLimit(LIM_AMPS ,CHK_OFF,0.0,0.0)
		self.SetLimit(LIM_TIME ,CHK_OFF,0.0,0.0)
		self.SetLimit(LIM_CAP  ,CHK_OFF,0.0,0.0)
		self.SetLimit(LIM_ENE  ,CHK_OFF,0.0,0.0)
		self.SaveSetup()
		return None

	def SaveLimits(self):
		fo = open(HOMEDIR+'LIMITS.TXT','w')
		fo.write(json.dumps(self.__Limits))
		fo.close()
		return None
		
	def LoadLimits(self):
		Success = False
		try:
			with open(HOMEDIR+'LIMITS.TXT','r') as fi:
				for line in fi:
					self.__Limits = json.loads(line)
					Success = True
		except FileNotFoundError:
			print('Error loading limits file')
		if Success: self.SaveSetup()
		return Success
		
	def LimitsReached(self):
		"""
			returns true if any of the limits has been reached
		"""
		res = False
		for lim in self.__Limits:
			if lim[LIM_MINHIT] or lim[LIM_MAXHIT]:
				res = True
				break
		return res
		
	def SaveSetup(self):
		fo = open(HOMEDIR+'SETUP.TXT','w')
		setup = [self.__Limits, 
		         self.__UseLoadVolts, 
		         self.__ShuntSelected,
		         self.__RecOpt,
		         self.__RunFields,
		         self.__SampRate,
		         self.__AutoRec]
		fo.write(json.dumps(setup))
		fo.close()
		return None
		
	def LoadSetup(self):
		Success = False
		setup = None
		try:
			with open(HOMEDIR+'SETUP.TXT','r') as fi:
				for line in fi:
					setup = json.loads(line)
					Success = True
		except FileNotFoundError:
			print('Error loading setup file')
		if Success:
			self.__Limits = setup[0]
			self.__UseLoadVolts = setup[1]
			self.__ShuntSelected = setup[2]
			self.__RecOpt = setup[3]
			self.__RunFields = setup[4]
			self.__SampRate = setup[5]
			self.__AutoRec = setup[6]
		return Success
		
	def Set_and_Validate_Limit(self,kind,hi,newval,newact):
		""" old        newact    newval    result
		hi = True
			chk_Min    False      any      Chk=nochange  Max=newval
			chk_Min    True       >Min     Chk= ALL      Max=newval, error if <= Min
			chk_Max	   False      any      Chk= OFF      Max=newval
			chk_Max	   True       any      Chk=nochange  Max=newval
			Chk_All	   False      any      Chk= MIN      Max=newval
			Chk_All    True       >Min     Chk=nochange  Max=newval, error if <= Min
			Chk_off    False      any      Chk=nochange  Max=newval
			Chk_off    True       any      Chk= MAX      Max=newval
		hi = False	
			chk_Min    False      any      Chk= OFF      Min=newval
			chk_Min    True       any      Chk=nochange  Min=newval
			chk_Max	   False      any      Chk=nochange  Min=newval
			chk_Max	   True       <Max     Chk= ALL      Min=newval, error if >= MAX
			Chk_All	   False      any      Chk= MAX      Min=newval
			Chk_All    True       <Max     Chk=nochange  Min=newval, error if >= Max
			Chk_off    False      any      Chk=nochange  Min=newval
			Chk_off    True       any      Chk= MIN      Min=newval
		"""
		ErrorStatus = False
		if hi:
			if self.__Limits[kind][LIM_CHECK] == CHK_MIN:
				if newact and (newval <= self.__Limits[kind][LIM_MINVAL]):
					#print('validation1',newval,'<=',self.__Limits[kind][LIM_MINVAL])
					ErrorStatus = True
				else:
					if newact: self.__Limits[kind][LIM_CHECK] = CHK_ALL
					self.__Limits[kind][LIM_MAXVAL] = newval
					self.__Limits[kind][LIM_MAXHIT] = False
			elif self.__Limits[kind][LIM_CHECK] == CHK_MAX:
				if not newact: self.__Limits[kind][LIM_CHECK] = CHK_OFF
				self.__Limits[kind][LIM_MAXVAL] = newval
				self.__Limits[kind][LIM_MAXHIT] = False
			elif self.__Limits[kind][LIM_CHECK] == CHK_ALL:
				if newact and (newval <= self.__Limits[kind][LIM_MINVAL]):
					#print('validation2',newval,'<=',self.__Limits[kind][LIM_MINVAL])
					ErrorStatus = True
				else:
					if not newact: self.__Limits[kind][LIM_CHECK] = CHK_MIN
					self.__Limits[kind][LIM_MAXVAL] = newval
					self.__Limits[kind][LIM_MAXHIT] = False
			else:
				if newact: self.__Limits[kind][LIM_CHECK] = CHK_MAX
				self.__Limits[kind][LIM_MAXVAL] = newval
				self.__Limits[kind][LIM_MAXHIT] = False
		else:
			if self.__Limits[kind][LIM_CHECK] == CHK_MIN:
				if not newact: self.__Limits[kind][LIM_CHECK] = CHK_OFF
				self.__Limits[kind][LIM_MINVAL] = newval
				self.__Limits[kind][LIM_MINHIT] = False
			elif self.__Limits[kind][LIM_CHECK] == CHK_MAX:
				if newact and (newval >= self.__Limits[kind][LIM_MAXVAL]):
					#print('validation3',newval,'>=',self.__Limits[kind][LIM_MAXVAL])
					ErrorStatus = True
				else:
					if newact: self.__Limits[kind][LIM_CHECK] = CHK_ALL
					self.__Limits[kind][LIM_MINVAL] = newval
					self.__Limits[kind][LIM_MINHIT] = False
			elif self.__Limits[kind][LIM_CHECK] == CHK_ALL:
				if newact and (newval >= self.__Limits[kind][LIM_MAXVAL]):
					#print('validation4',newval,'>=',self.__Limits[kind][LIM_MAXVAL])
					ErrorStatus = True
				else:
					if not newact: self.__Limits[kind][LIM_CHECK] = CHK_MAX
					self.__Limits[kind][LIM_MINVAL] = newval
					self.__Limits[kind][LIM_MINHIT] = False
			else:
				if newact: self.__Limits[kind][LIM_CHECK] = CHK_MIN
				self.__Limits[kind][LIM_MINVAL] = newval
				self.__Limits[kind][LIM_MINHIT] = False
		return ErrorStatus


	
	def GetOverflow(self)  : return self.__Overflow
	def GetVolts(self)     : return self.__Volts
	def GetCurrent(self)   : return self.__Current
	def GetPower(self)     : return self.__Power
	def GetCapacity(self)  : return self.__Capacity
	def GetEnergy(self)    : return self.__Energy
	def GetRunning(self)   : return self.__Running
	def GetHiVolts(self)   : return self.__HiVolts
	def GetHiCurrent(self) : return self.__HiCurrent
	def GetHiPower(self)   : return self.__HiPower
	def GetAvVolts(self)   : return self.__AvVolts
	def GetAvCurrent(self) : return self.__AvCurrent
	def GetAvPower(self)   : return self.__AvPower
	def GetLoVolts(self)   : return self.__LoVolts
	def GetLoCurrent(self) : return self.__LoCurrent
	def GetLoPower(self)   : return self.__LoPower
	def GetLoadVolts(self) : return self.__LoadVolts
	def GetShuntVolts(self): return self.__ShuntVolts
	def GetINAPower(self)  : return self.__INAPower
	def GetINACurrent(self): return self.__INACurrent
	def GetSamples(self)   : return self.__Samples
	
	def NewData(self,vapso):
		"""
			processes a new measurement in the form of the vapso parameter
			containing busvolts, amps, power, shunt voltage and overflow
			from the INA219
			
			It does statistics by calculating highest, mean, and lowest voltage
			current and power and calculates capacity and energy using the 
			elapsed time and the average current and average power
			
			It checks if any limits have been reached and if so returns 
			True, otherwise False
		
		"""
		def Check_Threshold(kind,newval):
			lim = self.__Limits[kind]
			
			if (lim[LIM_CHECK] == CHK_MIN) or (lim[LIM_CHECK] == CHK_ALL):
				lim[LIM_MINHIT] = newval <= lim[LIM_MINVAL]
			
			if (lim[LIM_CHECK] == CHK_MAX) or (lim[LIM_CHECK] == CHK_ALL):
				lim[LIM_MAXHIT] = newval >= lim[LIM_MAXVAL]
			return lim
		
		now = perf_counter() 
		self.__Overflow= vapso[OVER]
		self.__Running   = now - self.__StartTime
		self.__Samples   = self.__Samples + 1 
		self.__LoadVolts = vapso[VOLTS]
		self.__INACurrent= vapso[AMPS]
		self.__ShuntVolts= vapso[SHUNT]
		self.__INAPower  = vapso[PWR]
	
		"""
			use INA measurements directly for load volts 
			source voltage is INA load voltage + INA shunt voltage
		"""
		if self.__UseLoadVolts:
			self.__Volts = self.__LoadVolts
		else:
			self.__Volts = self.__LoadVolts + self.__ShuntVolts
		
		"""
			use shunt voltage and calibrated resistance for current 
		"""
		self.__Current = self.__ShuntVolts / self.__ShuntList[self.__ShuntSelected][SHUNTVAL]
		"""
			INA does not do signed power so we have to calculate it 
			in all cases. 
		"""
		self.__Power = self.__Volts * self.__Current
			
		self.__SumVolts  = self.__SumVolts + self.__Volts
		self.__SumCurrent= self.__SumCurrent + self.__Current
		self.__SumPower  = self.__SumPower + self.__Power

		self.__AvVolts	 = self.__SumVolts / self.__Samples
		self.__AvCurrent = self.__SumCurrent / self.__Samples
		self.__AvPower   = self.__SumPower / self.__Samples
		
		self.__Capacity  = (self.__AvCurrent * self.__Running) / 3600.0
		self.__Energy 	 = (self.__AvPower * self.__Running) / 3600.0
		
		if self.__Volts > self.__HiVolts: 
			self.__HiVolts = self.__Volts
		if self.__Volts < self.__LoVolts: 
			self.__LoVolts = self.__Volts
		
		if self.__Current > self.__HiCurrent: 
			self.__HiCurrent = self.__Current
		if self.__Current < self.__LoCurrent: 
			self.__LoCurrent = self.__Current
			
		if self.__Power > self.__HiPower: 
			self.__HiPower = self.__Power
		if self.__Power < self.__LoPower: 
			self.__LoPower = self.__Power
			
		
				
		self.__Limits[LIM_VOLTS] = Check_Threshold(LIM_VOLTS, self.__Volts)
		self.__Limits[LIM_AMPS]  = Check_Threshold(LIM_AMPS, self.__Current)
		self.__Limits[LIM_TIME]  = Check_Threshold(LIM_TIME, self.__Running)
		self.__Limits[LIM_CAP]   = Check_Threshold(LIM_CAP,  self.__Capacity * 1000.0)
		self.__Limits[LIM_ENE]   = Check_Threshold(LIM_ENE,  self.__Energy * 1000.0)
		return self.LimitsReached() 
		
		
	def __init__(self):
		""" The constructor reads the calibration data set containing a 
			list of shunts and their CALDAT sets. 
		"""
		self.ClearAllMeasurements()
		
		try:
			with open(HOMEDIR+'CALDATA.TXT','r') as fi:
				n = 0
				for line in fi:
					n = n +1
					"""	the first line is a pair of numbers for the
						bus voltage calibration: 
							- BVSLOPE the calibration slope 
						    - BVINTER the calibration intercept
						the next line is four pairs of numbers for the
						shunt voltage calibration: 
							- SVSLOPE the calibration slope 
						    - SVINTER the calibration intercept
						followed by x-lines for shunt resistors with: 
						- SHUNTNAM  a name 
						- SHUNTRES  the nominal value of the shunt resistor in ohms
						- SHUNTVAL  the actual value of the shunt resistor in ohms
						- CALDAT    a list of four pairs of numbers which are:
									- CALREG: the value for the INA219 calibration register 
									- CURLSB the chosen current LSB 
					"""
					CalData = json.loads(line)
					if n == 1:
						self.__BVCalData = CalData
					elif n == 2:
						self.__SVCalData = CalData
					else:
						self.__ShuntList.append(CalData)
		except:
			print("CALDATA error:", sys.exc_info()[0])
			defCalData = ['default',0.1,0.1,
							[[32768,0.0000125],
							 [16384,0.000025],
							 [8192,0.000050],
							 [4096,0.000100]]]
			self.__ShuntList.append(defCalData)
			self.__BVCalData = [1.0,0.0]
			self.__SVCalData = [[1.0,0.0],[1.0,0.0],[1.0,0.0],[1.0,0.0]]
			self.__ShuntSelected = 0
			self.__ShuntVal = 0.1
			


