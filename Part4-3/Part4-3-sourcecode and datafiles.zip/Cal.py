#!/usr/bin/env python3
#MIT License
#
#Copyright (c) 2019 TheHWcave
#
#Permission is hereby granted, free of charge, to any person obtaining a copy
#of this software and associated documentation files (the "Software"), to deal
#in the Software without restriction, including without limitation the rights
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#copies of the Software, and to permit persons to whom the Software is
#furnished to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
#SOFTWARE.
#

from CommonDefs import *
from LCDpanel import *
from Buttons import ScanButtons, BUTTON1, BUTTON2, BUTTON3, BUTTON4, NO_EVENT,SHORT_PRESS, LONG_PRESS
import copy

class Cal:
	"""
		Calibration of either bus voltage, shunt voltage(s) or shunt resistor.
				
		For bus voltage and shunt voltage, calibration has 2 steps:
			1 first a low target is presented
			  once the actual value measured by an external meter(!) 
			  matches the target SEL is pressed  and the values stored
			2 next a high target is presented 
			  once the actual value as measured by an external meter(!)
			  matches the target SEL is pressed  and a new SLOPE 
			  and INTERCEPT are calculated, applied and stored in CALDATA
		
		For shunt resistance, calibration has only 1 step and it assumes
		that shunt voltage has been calibrated before:
			1. A current target (expressed a shunt voltage over the 
			   nominal shunt resistance) is presented
			   When the actual shunt voltage as measured by an external
			   meter(!) matches the target, SEL is pressed and the actual
			   shunt resistor value is calculated, applied and stored in 
			   CALDATA
			 
		While calibration for a particular item is going on, any 
		existing calibration for that item is turned-off temporarily
		
		During shunt voltage calibration manual range is automatically 
		selected
		
		If calibration is cancelled before the final step, the original
		calibration values are restored. 
		
		
		Returns MENU_PENDING except as shown below:
		Handles the events
		  Button   press     
			1      short   : (not used)
			1      long    : (not used)
			2      short   : for shunt resistance: do calibration and exit
							 for others: 
							    if 1st target: store and preset 2nd target
							    if 2nd target: do calibration and exit 
			2      long    : (not used)
			3      short   : (not used)
			3      long    : (not used)
			4      short   : abort calibration, restore previous values
						     and return MENU_BACK  
			4      long	   : abort calibration, restore previous values
							 and return MENU_TOP
			
	"""

	
	__data   	= None
	__ina		= None
	__disp		= None
	
	
	__PERCENT_LO   = 0.05
	__PERCENT_HI   = 0.95
	__SHUNTCURRENT = 1.0
	
	__BVT = 20
	__SVT = [0.04,0.08,0.16,0.32]
	__SVrange = 0
	
	
	__Target     = [0.0,0.0]
	__INAval	 = [0.0,0.0]
	
	__CalBVolt_old=[0.0,0.0]
	__CalBVolt_new=[0.0,0.0]
	__CalSVolt_old=[[0.0,0.0],[0.0,0.0],[0.0,0.0],[0.0,0.0]]
	__CalSVolt_new=[[0.0,0.0],[0.0,0.0],[0.0,0.0],[0.0,0.0]]
	__CalShunt_old= 0.0
	__CalShunt_new= 0.0
	__CalShunt_nom= 0.0


	__firstcall	= True
	__selval	= None
	__cursor	= None

	

	



	def DoCal(self,Ev,CalItem):
		res = MENU_PENDING
		if self.__firstcall:
			self.__firstcall = False
			self.__selval = 0
			WriteLCD(0,1,"    SEL     BACK")
			"""
				get current values of all calibration data items 
				and save them as old values - to be able
				to restore them to their original values if calibration
				is abandoned
			"""
			self.__CalBVolt_old = self.__data.GetBVoltCalData()
			self.__CalSVolt_old = self.__data.GetSVoltCalData()
			self.__CalShunt_old = self.__data.GetShuntAValue()
			self.__CalShunt_nom = self.__data.GetShuntNValue()
			
			if (CalItem >= DOCAL_SV_A) and (CalItem  <= DOCAL_SV_D):
				"""
					calculate target values for calibration of this
					shuntvoltage range and set the range to manual 
				"""
				self.__SVrange = CalItem - DOCAL_SV_A
				self.__Target[0] = self.__SVT[self.__SVrange] * self.__PERCENT_LO
				self.__Target[1] = self.__SVT[self.__SVrange] * self.__PERCENT_HI
				self.__ina.SetRange(MAN_RANGE,self.__SVrange)
				"""
					save present shuntvoltage calibration values for that range
					and then turn calibration off by setting slope 
					to 1 and intercept to 0  
				"""
				self.__CalSVolt_new = copy.deepcopy(self.__CalSVolt_old)
				self.__CalSVolt_new[self.__SVrange][SVSLOPE] = 1.0
				self.__CalSVolt_new[self.__SVrange][SVINTER] = 0.0
				self.__ina.SetCalSVolt(self.__CalSVolt_new)
			elif CalItem == DOCAL_BV:
				"""
					calculate target values for calibration of the
					bus voltage range 
				"""
				self.__Target[0] = self.__BVT * self.__PERCENT_LO
				self.__Target[1] = self.__BVT * self.__PERCENT_HI
				"""
					save present voltage calibration values
					and then turn calibration off by setting slope 
					to 1 and intercept to 0
				"""
				self.__CalBVolt_new[BVSLOPE] = 1.0
				self.__CalBVolt_new[BVINTER] = 0.0
				self.__ina.SetCalBVolt(self.__CalBVolt_new)
			else: # DOCAL_SHUNT
				"""
					set a target current  
					Reset any existing shunt calibration 
				"""
				self.__Target[0] = self.__SHUNTCURRENT 
				self.__data.SetShuntAValue(self.__CalShunt_nom)
				self.__ina.SetRange(AUTO_RANGE,SHUNT_320MV)
		if CalItem == DOCAL_BV:
			self.__INAval[self.__selval] = self.__data.GetVolts()
		else:
			self.__INAval[self.__selval] = self.__data.GetShuntVolts()
		
			
		INAvalstr = self.__disp.Volts2String(self.__INAval[self.__selval])
		if CalItem == DOCAL_SHUNT:
			Targetstr = self.__disp.Current2String(self.__Target[self.__selval])
		else:
			Targetstr = self.__disp.Volts2String(self.__Target[self.__selval])
		
		WriteLCD(0,0,Targetstr,False)
		WriteLCD(8,0,INAvalstr,False)
		
		if Ev == (BUTTON2,SHORT_PRESS): # SEL
			if self.__selval == 0:
				if CalItem != DOCAL_SHUNT:
					self.__selval = 1
				else: 
					shuntA = self.__INAval[0] / self.__SHUNTCURRENT
					self.__data.SetShuntAValue(shuntA)
					self.__data.UpdateCalData(self.__CalBVolt_old,self.__CalSVolt_old)
					res = MENU_ENTER
			else:
				slope = (self.__INAval[1] - self.__INAval[0]) / (self.__Target[1] - self.__Target[0])
				inter = self.__INAval[0] - slope * self.__Target[0]
				#print(slope, inter)
				if (CalItem == DOCAL_BV): 
					self.__CalBVolt_new[BVSLOPE] = slope
					self.__CalBVolt_new[BVINTER] = inter
					self.__ina.SetCalBVolt(self.__CalBVolt_new)
					self.__data.UpdateCalData(self.__CalBVolt_new,self.__CalSVolt_old)
				else:
					self.__CalSVolt_new[self.__SVrange][SVSLOPE] = slope
					self.__CalSVolt_new[self.__SVrange][SVINTER] = inter
					self.__ina.SetCalSVolt(self.__CalSVolt_new)
					self.__data.UpdateCalData(self.__CalBVolt_old,self.__CalSVolt_new)
				res = MENU_ENTER
		elif Ev == (BUTTON4,SHORT_PRESS): # BACK
			self.__ina.SetCalSVolt(self.__CalSVolt_old)
			self.__ina.SetCalBVolt(self.__CalBVolt_old)
			self.__data.SetShuntAValue(self.__CalShunt_old)
			self.__data.UpdateCalData(self.__CalBVolt_old,self.__CalSVolt_old)
			res = MENU_BACK
		elif Ev == (BUTTON4,LONG_PRESS): # BACK long press
			self.__ina.SetCalSVolt(self.__CalSVolt_old)
			self.__ina.SetCalBVolt(self.__CalBVolt_old)
			self.__data.SetShuntAValue(self.__CalShunt_old)
			self.__data.UpdateCalData(self.__CalBVolt_old,self.__CalSVolt_old)
			res = MENU_TOP
		if res != MENU_PENDING:
			self.__firstcall = True
		return res
			
			
	def __init__(self, data, ina, disp):
		""" setup a menu of to allow calibration of bus voltage or shunt voltage(s) 
		
				
		"""

		
		self.__data    = data
		self.__ina     = ina
		self.__disp	   = disp
		
	
		self.__firstcall = True
		self.__selval = 0

		
