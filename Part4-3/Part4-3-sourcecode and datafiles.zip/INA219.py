#!/usr/bin/env python3
#MIT License
#
#Copyright (c) 2019 TheHWcave
#
#Permission is hereby granted, free of charge, to any person obtaining a copy
#of this software and associated documentation files (the "Software"), to deal
#in the Software without restriction, including without limitation the rights
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#copies of the Software, and to permit persons to whom the Software is
#furnished to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
#SOFTWARE.
#

import Adafruit_GPIO.I2C as I2C
from CommonDefs import *
from time import sleep
import copy
class INA219:
	_ina = None

	INVALID = 9999.9 # invalid value (uninitialized or overflow)
	INA_SHUNT_40MV  = 0
	INA_SHUNT_80MV  = 1
	INA_SHUNT_160MV = 2
	INA_SHUNT_320MV = 3

	
	__INA_REG_CONFIG  = 0x00
	__INA_REG_SHUNT_V = 0x01
	__INA_REG_BUS_V   = 0x02
	__INA_REG_POWER   = 0x03
	__INA_REG_CURRENT = 0x04
	__INA_REG_CAL     = 0x05

	__INA_BUS_16V     = 0
	__INA_BUS_32V     = 1



	__INA_ADC_12B_1S  = 0x03
	__INA_ADC_12B_2S  = 0x09
	__INA_ADC_12B_4S  = 0x0A
	__INA_ADC_12B_8S  = 0x0B
	__INA_ADC_12B_16S = 0x0C
	__INA_ADC_12B_32S = 0x0D
	__INA_ADC_12B_64S = 0x0E
	__INA_ADC_12B_128S= 0x0F
	
	__INA_MODE_S_B_C  = 0x07  # shunt and bus  continuous 
	
	__INA_MAX_SHUNTVOLT = (4000,8000,16000,32000)  # equiv to 40,80,160,320 mV
	
	# __SHUNT has the format [SHUNTNAM,SHUNTRES,SHUNTVAL,CALDATA]
	#   		with CALDATA a list of [CALREG,CURLSB],..[CALREG,CURLSB]]
	__Shunt			  = []
	
	__CalBVolt		  = []  # [BVSLOPE,BVINTER]
	__CalSVolt		  = []  # [SVSLOPE,SVINTER]
	
	__MaxVolts	      = 21.0
	__SampleRate	  = __INA_ADC_12B_2S

	__Range = [AUTO_RANGE, INA_SHUNT_320MV]
	__RANGE_MODE      = 0 
	__RANGE_VALUE     = 1  
	
	# how long a measurement takes in sec, depending on sample rate
	#                 1       2      4     8    16   32    64   128
	__SAMPLETIME = (0.0005,0.001,0.002,0.004,0.008,0.016,0.032,0.064) 
	__SampleWait = 0.0 #  selected waiting time
	
	#accessing SAMPLE elements
	__BVREG = 0
	__SVREG = 1
	__PWREG = 2
	__CUREG = 3
	__OVBIT = 4


		
	def _writereg(self,reg, regval):
		value_pair = [(regval >> 8)&0xFF,regval & 0xFF]
		INA219._ina.writeList(reg,value_pair)
		return None
		
	def _configure_INA(self,svrange,samplerate):
		"""
			svrange is the shunt voltage range  0..3 (40..320mV)
			samplerate is 0x08..  to 0x0F for 1..128 samples
		"""
		configval = self.__INA_MODE_S_B_C + \
				0x0008 * samplerate + \
				0x0080 * samplerate + \
				0x0800 * svrange    + \
				0x2000 * self.__INA_BUS_32V 
		self._writereg(self.__INA_REG_CONFIG,configval)
		self._writereg(self.__INA_REG_CAL,self.__Shunt[CALCUR][svrange][CALREG])
		return None
	

	def Read_raw_measurement(self):
		newdata = False
		ovbit = False
		while not newdata:
			regval = INA219._ina.readU16BE(self.__INA_REG_BUS_V)
			if regval & 0x0002 == 0x0002:
				newdata = True
			if regval & 0x0001 == 1: #math overflow occured
				ovbit = True
			if self.__SampleRate > self.__INA_ADC_12B_8S:
				newdata = True # don't wait if sampling is set to 16 or more
			else:
				sleep(self.__SampleWait)
		bvreg = regval >> 3
		svreg = INA219._ina.readS16BE(self.__INA_REG_SHUNT_V)
		pwreg = INA219._ina.readU16BE(self.__INA_REG_POWER)
		cureg = INA219._ina.readS16BE(self.__INA_REG_CURRENT)
		return (bvreg,svreg,pwreg,cureg,ovbit)
	
	#	end of low-level INA219 access functions
	#-------------------------------------------------------------------
	#
	def Setup(self,NewShunt, NewCalBVolt, NewCalSVolt, MaxVolts = 21.0):
		"""
			Setup INA with the shunt and matching Calibration data given
			as parameters. 
		"""
		self.__Shunt      = NewShunt
		self.__CalBVolt   = copy.deepcopy(NewCalBVolt)
		self.__CalSVolt   = copy.deepcopy(NewCalSVolt)
		self.__MaxVolts	  = MaxVolts
		self._configure_INA(self.__Range[self.__RANGE_VALUE],self.__SampleRate)
		return None
		
		
	def SetRange(self,mode,mr):
		"""
			Switches between manual range and auto range mode. 
			for auto mode, the range value in the mr  parameter
			is ignored
			for manual mode, the mr parameter must be one of the 
			four definded INA range values 
			"""
		if mode == AUTO_RANGE:
			self.__Range = [AUTO_RANGE, self.INA_SHUNT_320MV]
		else:
			self.__Range = [MAN_RANGE, mr]
			self._configure_INA(mr,self.__SampleRate)
		return None
		
	def GetRangeValue(self):
		return self.__Range[self.__RANGE_VALUE]
	
	def GetRangeMode(self):
		return self.__Range[self.__RANGE_MODE]


	def SetADCSampling(self,Sampling):
		"""
			Set the INA sampling rate
		"""
		self.__SampleRate = 0b1000 + Sampling
		self.__SampleWait = self.__SAMPLETIME[Sampling]
		self._configure_INA(self.__Range[self.__RANGE_VALUE],self.__SampleRate)
		return None
		
		
	def SetShunt(self,NewShunt):
		self.__Shunt = list(NewShunt)
		self._configure_INA(self.__Range[self.__RANGE_VALUE],self.__SampleRate)
		return None
		
	def SetCalBVolt(self,NewCalBVolt):
		self.__CalBVolt = copy.deepcopy(NewCalBVolt)
		return None
		
	def SetCalSVolt(self,NewCalSVolt):
		self.__CalSVolt = copy.deepcopy(NewCalSVolt)
		return None
		
	def Read_INA(self):
		"""
			Read values from INA, performing auto range if in Auto mode
			
			Auto: read the shunt voltage and compare it to the allowed 
			values starting with the highest range. Stop at the highest 
			range that includes the current value.
			
			Read_INA returns a list of values containing:
			busvolts, current (amps), power, shunt voltage, and an overflow 
			indiator. 
			
			Set the overflow in addition if MaxVolts has been reached or
			exceeded
			
			
			
		"""
		
			
		Sample = self.Read_raw_measurement()
		
		#print(str(Sample[BVREG])+','+str(Sample[SVREG]))
		r = self.__Range[self.__RANGE_VALUE]
		if self.__Range[self.__RANGE_MODE] == AUTO_RANGE:
			asv = abs(Sample[self.__SVREG])
			nr = self.INA_SHUNT_320MV
			if asv < self.__INA_MAX_SHUNTVOLT[self.INA_SHUNT_320MV]:
				nr = self.INA_SHUNT_40MV
				for tr in range(self.INA_SHUNT_320MV,self.INA_SHUNT_40MV,-1):
					if asv <= self.__INA_MAX_SHUNTVOLT[tr] and asv >= self.__INA_MAX_SHUNTVOLT[tr-1]:
						nr = tr
						break
			if (nr >= self.INA_SHUNT_40MV) and (nr != r):
				self.__Range[self.__RANGE_VALUE] = nr
				self._configure_INA(nr,self.__SampleRate) 
				r = nr
				Sample = self.Read_raw_measurement()
		o = Sample[self.__OVBIT] or (abs(Sample[self.__SVREG]) >= self.__INA_MAX_SHUNTVOLT[r]) # set overflow if shuntrange exceeded
		s = float(Sample[self.__SVREG]) * 0.00001
		p = float(Sample[self.__PWREG]) * 20* self.__Shunt[CALCUR][r][CURLSB]
		a = float(Sample[self.__CUREG]) * self.__Shunt[CALCUR][r][CURLSB]
		v = float(Sample[self.__BVREG]) * 0.004
		"""
		Bus voltage and shunt voltage correction relies on a SLOPE and INTERCEPT parameter.
		No correction when SLOPE = 1.0 and INTERCEPT = 0
			
			Need to apply reference voltages / currents: REFlo and REFhi 
			and get the corresponding INA readings INAlo and INAhi
			
			SLOPE =  (INA219hi - INA219lo)/(REFhi - REFlo)
		    INTERCEPT = INA219lo-SLOPE*REFlo
		    
		then:
			
			x = (INAx - INTERCEPT) / SLOPE
		"""
		v = (v - self.__CalBVolt[BVINTER]) / self.__CalBVolt[BVSLOPE]
		s = (s - self.__CalSVolt[r][SVINTER]) / self.__CalSVolt[r][SVSLOPE]
		
		
		if not o and (v >= self.__MaxVolts or v+s >=self.__MaxVolts):
			o = True
		return (v,a,p,s,o)

	def __init__(self,NewShunt,NewCalBVolt,NewCalSVolt,Samples,MaxVolts=21.0):
		""" setup the INA connection as a singelton with defaults
			every other instance of this class uses the same INA object
		"""
		if INA219._ina == None:
			INA219._ina = I2C.get_i2c_device(address=0x40, busnum=None)
			
		self.Setup(NewShunt,NewCalBVolt,NewCalSVolt,MaxVolts)
		self.SetADCSampling(Samples)

