#!/usr/bin/env python3
#MIT License
#
#Copyright (c) 2019 TheHWcave
#
#Permission is hereby granted, free of charge, to any person obtaining a copy
#of this software and associated documentation files (the "Software"), to deal
#in the Software without restriction, including without limitation the rights
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#copies of the Software, and to permit persons to whom the Software is
#furnished to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
#SOFTWARE.
#

from CommonDefs import *
from LCDpanel import *
from Buttons import ScanButtons, BUTTON1, BUTTON2, BUTTON3, BUTTON4, NO_EVENT,SHORT_PRESS, LONG_PRESS

class Edit:
	"""
		needs to be instantiated to set minimum, maximum allowed values and 
		if negative and floating point or integer numbers are being edited
		
		shows the current value behind the prompt on 1st row and
		the text PREV SEL NEXT BACK on second
		
		editing uses the place value of the number corresponding to the cursor
		position. 
		
		values (e.g. limits) can be set active or inactive as well as numerically edited
		
		returns MENU_PENDING except as shown below:
		Handles the events
		  Button   press     
			1      short   : decrement value by the place value, stop at 0 (or minimum)
			1      long    : move cursor one to the left, stop when highest place value is reached
			2      short   : select current value and state and return MENU_ENTER
			2      long    : toggle active state of current value and return MENU_ENTER
			3      short   : increment value by the place value, stop at maximum
			3      long    : move cursor one to the right, stop when lowest place value is reached
			4      short   : return MENU_BACK and reset selected option 
			4      long	   : (not used)
			
	"""


	__VALMIN   = 0
	__VALMAX   = 0
	__VALNEG   = False
	__VALFLOAT = True
		
	__firstcall	= True
	__selval	= None  # is a list  [value, active]  
	__cursor	= None
	__MAXCURSOR = None
	__MINCURSOR = None
	
	__PLACEVAL_F = (10.000,1.000,-1,0.100,0.010,0.001)
	__PLACEVAL_I = (10000,1000,100,10,1)

	def GetSelected(self):	
		return self.__selval  # this is a pair of values [value, active]

	def EditVal(self,Ev,Prompt, Curval):  #curval is a pair of values [value, active]
		res = MENU_PENDING
		if self.__firstcall:
			self.__selval = Curval
			WriteLCD(0,0,Prompt.ljust(8))
			WriteLCD(0,1,"< - SEL + > BACK")
			self.__MINCURSOR = 0
			if self.__VALFLOAT:
				self.__MAXCURSOR = 5
			else:
				self.__MAXCURSOR = 4
			self.__cursor = self.__MAXCURSOR
			self.__firstcall = False

		if self.__VALFLOAT:
			#   01234567
			#  +12.345x 
			#   12.345x   
			#   ^         cursor between 0 and 5
			#
			if self.__VALNEG:
				s = '{:+07.3f}'.format(self.__selval[RETVAL_VAL])
			else:
				s = ' {:06.3f}'.format(self.__selval[RETVAL_VAL])
			if self.__selval[RETVAL_ACT]:
				s = s + chr(CH_TICK)
			else:
				s = s + chr(CH_DOT)
			WriteLCD(8,0,s,False)
			ShowCursor(self.__cursor+8+1,0)
		
			if Ev == (BUTTON1,SHORT_PRESS): # dec
				newval = self.__selval[RETVAL_VAL] - self.__PLACEVAL_F[self.__cursor]
				if newval < self.__VALMIN:
					newval = self.__VALMIN
				elif (newval < 0.0) and not self.__VALNEG:
					newval = 0.0
				self.__selval[RETVAL_VAL] = newval		
			elif Ev == (BUTTON3,SHORT_PRESS): # inc
				newval = self.__selval[RETVAL_VAL] + self.__PLACEVAL_F[self.__cursor]
				if newval > self.__VALMAX:
					newval = self.__VALMAX
				self.__selval[RETVAL_VAL] = newval		
			elif Ev == (BUTTON1,LONG_PRESS): # cursor left
				if self.__cursor > self.__MINCURSOR:
					self.__cursor = self.__cursor - 1
					if self.__cursor == 2: self.__cursor = 1 # hopp over dec.point
			elif Ev == (BUTTON3,LONG_PRESS): # cursor right
				if self.__cursor < self.__MAXCURSOR:
					self.__cursor = self.__cursor + 1
					if self.__cursor == 2: self.__cursor = 3 # hopp over dec.point
			elif Ev == (BUTTON2,SHORT_PRESS): # select
				res = MENU_ENTER
			elif Ev == (BUTTON2,LONG_PRESS): # activate / deact
				self.__selval[RETVAL_ACT] = not self.__selval[RETVAL_ACT]
				res = MENU_ENTER
			elif Ev == (BUTTON4,SHORT_PRESS): # back
				res = MENU_BACK
				self.__selval = Curval
			elif Ev == (BUTTON4,LONG_PRESS): # back long press
				res = MENU_TOP
				self.__selval = Curval
		else: 
			# INTEGER EDITING
			# ---------------
			#  01234567 
			#  +12345
			#   12345      cursor between 0 and 4
			if self.__VALNEG:
				s = '{:+06d}'.format(int(self.__selval[RETVAL_VAL]))
			else:
				s = ' {:05d}'.format(int(self.__selval[RETVAL_VAL]))
			if self.__selval[RETVAL_ACT]:
				s = s + chr(CH_BALL)
			else:
				s = s + 'o'
			WriteLCD(8,0,s,False)
			ShowCursor(self.__cursor+8+1,0)
		
			if Ev == (BUTTON1,SHORT_PRESS): # dec
				newval = self.__selval[RETVAL_VAL] - self.__PLACEVAL_I[self.__cursor]
				if newval < self.__VALMIN:
					newval = self.__VALMIN
				elif (newval < 0.0) and not self.__VALNEG:
					newval = 0.0
				self.__selval[RETVAL_VAL] = newval		
			elif Ev == (BUTTON3,SHORT_PRESS): # inc
				newval = self.__selval[RETVAL_VAL] + self.__PLACEVAL_I[self.__cursor]
				if newval > self.__VALMAX:
					newval = self.__VALMAX
				self.__selval[RETVAL_VAL] = newval		
			elif Ev == (BUTTON1,LONG_PRESS): # cursor left
				if self.__cursor > self.__MINCURSOR:
					self.__cursor = self.__cursor - 1
			elif Ev == (BUTTON3,LONG_PRESS): # cursor right
				if self.__cursor < self.__MAXCURSOR:
					self.__cursor = self.__cursor + 1
			elif Ev == (BUTTON2,SHORT_PRESS): # select
				res = MENU_ENTER
			elif Ev == (BUTTON2,LONG_PRESS): # activate / deact
				self.__selval[RETVAL_ACT] = not self.__selval[RETVAL_ACT]
				res = MENU_ENTER
			elif Ev == (BUTTON4,SHORT_PRESS): # back
				res = MENU_BACK
				self.__selval = Curval
		if res != MENU_PENDING:
			self.__firstcall = True
		return res


	def __init__(self,Min,Max,CanBeNeg,UseFloat):
		""" setup an edit menu
			
			Min = minimum allowed value
			Max = maximum allowed value
			CanBeNeg: if True, the value can be negative, 
			          otherwise only positive values are allowed
			UseFloat: if True, the value is a floating point number
			          otherwise it is an integer 
			
		"""

		self.__VALMIN   = Min
		self.__VALMAX   = Max
		self.__VALNEG   = CanBeNeg
		self.__VALFLOAT = UseFloat
		
	
		self.__firstcall = True
		self.__selval = 0
		self.__cursor = 0
		
