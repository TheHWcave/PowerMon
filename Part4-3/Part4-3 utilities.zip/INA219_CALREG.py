#!/usr/bin/env python3
#MIT License
#
#Copyright (c) 2019 TheHWcave
#
#Permission is hereby granted, free of charge, to any person obtaining a copy
#of this software and associated documentation files (the "Software"), to deal
#in the Software without restriction, including without limitation the rights
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#copies of the Software, and to permit persons to whom the Software is
#furnished to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
#SOFTWARE.
#

from decimal import *


    


def GetAFloat(prompt):
	Done = False
	while not Done:
		try:
			instr =  input(prompt)
			f = float(instr)
			Done = True
		except ValueError:
			print('error converting "'+instr+'" to float')
	return f

def Float2Str(f):
	d = Decimal(f)
	return d.to_eng_string()[:10] 

SV_RANGES = (0.04,0.08,0.16,0.32)
Results   = [[0,0.0],[0,0.0],[0,0.0],[0,0.0]]


if __name__ == "__main__":
	r = 0
	shunt = GetAFloat('Enter the shunt resistor in Ohm:')
	
	for SVR in SV_RANGES:
		max_current = SVR/shunt
		min_LSB	    = max_current / 32767
		max_LSB		= max_current / 4096
		Done = False
		while not Done:
			cur_LSB = GetAFloat('range +-{:4.2f}A'.format(max_current)+' enter current LSB between '+Float2Str(min_LSB)+
						' and '+Float2Str(max_LSB)+':')
			if cur_LSB >= min_LSB and cur_LSB <= max_LSB:
				Done = True
			else:
				print('error '+Float2Str(cur_LSB)+' is outside the allowed range')
		Results[r][0] = int(0.04096/(cur_LSB * shunt))
		Results[r][1] = cur_LSB
		r = r + 1	
	
	n = 0
	for r in Results:
		if n == 0:
			print('["'+str(shunt)+'",'+str(shunt)+','+str(shunt)+',[',end='')
		else:
			print(',',end='')
		print('['+str(r[0])+','+Float2Str(r[1]),end='')
		n = n + 1
	print(']]')
	
		
		
