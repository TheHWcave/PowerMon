#!/usr/bin/env python3
#MIT License
#
#Copyright (c) 2019 TheHWcave
#
#Permission is hereby granted, free of charge, to any person obtaining a copy
#of this software and associated documentation files (the "Software"), to deal
#in the Software without restriction, including without limitation the rights
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#copies of the Software, and to permit persons to whom the Software is
#furnished to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
#SOFTWARE.
#
from time import sleep,perf_counter

import board
import digitalio

button1 = digitalio.DigitalInOut(board.D5)
button1.direction = digitalio.Direction.INPUT
button1.pull = digitalio.Pull.UP

button2 = digitalio.DigitalInOut(board.D6)
button2.direction = digitalio.Direction.INPUT
button2.pull = digitalio.Pull.UP

button3 = digitalio.DigitalInOut(board.D12)
button3.direction = digitalio.Direction.INPUT
button3.pull = digitalio.Pull.UP

button4 = digitalio.DigitalInOut(board.D13)
button4.direction = digitalio.Direction.INPUT
button4.pull = digitalio.Pull.UP

BUTTON1 = 0
BUTTON2 = 1
BUTTON3 = 2
BUTTON4 = 3

ButtonStart = [0,0,0,0]
ButtonTouch = [False,False,False,False]

NO_EVENT    =0
SHORT_PRESS =1
LONG_PRESS  =2



def HandleButton(b,pressed,tick):
	LONG_LIMIT  = 1.0
	be = NO_EVENT
	if pressed:
		if  ButtonStart[b] == 0:
			ButtonStart[b] = tick
		else:
			if tick - ButtonStart[b] >= LONG_LIMIT:
				be = LONG_PRESS
				ButtonStart[b] = 0
				ButtonTouch[b] = True
	else:
		if ButtonStart[b] > 0:
			ButtonStart[b] = 0
			if not ButtonTouch[b]:
				be = SHORT_PRESS
			ButtonTouch[b] = False
	return be

def ScanButtons():
	now = perf_counter()
	butevent = [
	HandleButton(BUTTON1,not button1.value,now),
	HandleButton(BUTTON2,not button2.value,now),
	HandleButton(BUTTON3,not button3.value,now),
	HandleButton(BUTTON4,not button4.value,now)]
	res = (BUTTON1,NO_EVENT)
	if butevent[BUTTON4] != NO_EVENT:
		res = (BUTTON4,butevent[BUTTON4])
	elif butevent[BUTTON2] != NO_EVENT:
		res = (BUTTON2,butevent[BUTTON2])
	elif butevent[BUTTON3] != NO_EVENT:
		res = (BUTTON3,butevent[BUTTON3])
	elif butevent[BUTTON1] != NO_EVENT:
		res = (BUTTON1,butevent[BUTTON1])
	return res
	
