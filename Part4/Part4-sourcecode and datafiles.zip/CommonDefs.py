#!/usr/bin/env python3
#MIT License
#
#Copyright (c) 2019 TheHWcave
#
#Permission is hereby granted, free of charge, to any person obtaining a copy
#of this software and associated documentation files (the "Software"), to deal
#in the Software without restriction, including without limitation the rights
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#copies of the Software, and to permit persons to whom the Software is
#furnished to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
#SOFTWARE.
#
"""
	Contains a list of common definitions used in all modules and classes
	
"""
# special character values for the LCD display
# codes 0 .. 7 are user defined patters (see LCD_Panel module)
CH_HI    = 0     # shows "Hi"
CH_LO    = 1     # shows "Lo"
CH_HILO  = 2     # shows "HiLo"
CH_DN    = 3     # down arrow (matches CH_UP)
CH_DOTS  = 4     # dot-dot-dot
CH_MA    = 5     # milli-amp symbol
CH_MW    = 6     # milli-watt symbol
CH_MV    = 7     # milli-volt symbol
CH_OHM   = 0xf4  # the "Ohm" symbol
CH_XBAR  = 0xf8  # used for "average" or "mean"
CH_DEG   = 0xdf  # degree
CH_RIGHT  =0x7e  # right arrow
CH_LEFT   =0x7f  # left arrow
CH_UP     =0x5e  # up arrow
CH_BLOCK  =0xff  # solid block (all pixels on)
CH_DOT    =0xa5  # a small center dot
CH_TICK   =0xe8  # square root symbol
CH_MICRO  =0xe4  # greek letter mu

DOTS = chr(CH_DOTS) # shortcut to print the "Dots" character

INVALID = 99999.999  # marks a value as invalid

HOMEDIR = '/home/pi/INA/' # is where we live


# The shunt voltage ranges 
SHUNT_40MV  = 0
SHUNT_80MV  = 1
SHUNT_160MV = 2
SHUNT_320MV = 3

# Samples for averaging 
SAMPLES_1	= 0
SAMPLES_2	= 1
SAMPLES_4	= 2
SAMPLES_8	= 3
SAMPLES_16	= 4
SAMPLES_32	= 5
SAMPLES_64	= 6
SAMPLES_128	= 7

#SHUNTLIST access: These values are used to index shuntlist elements
SHUNTNAM= 0
SHUNTRES= 1
CALCUR  = 2
#CALVOLT = 3

#CALCUR access: These values are used to index the CALCUR element
CALREG  = 0
CURLSB  = 1
CURSLOPE= 2
CURINTER= 3
#CALVOLT access: These values are used to index the CALVOLT element
BVSLOPE = 0
BVINTER = 1

#VAPSO access: These values are used to index the VAPSO list 
VOLTS=0
AMPS =1
PWR  =2
SHUNT=3
OVER =4

AUTO_RANGE      = 0
MAN_RANGE       = 1

#Limits: These values enumerate the type of Hi Lo limits checks available 
LIM_VOLTS = 0  # Hi and Lo Volts
LIM_AMPS  = 1  # Hi and Lo Amps
LIM_TIME  = 2  # Hi running time  (Lo not used)
LIM_CAP   = 3  # Hi capacity      (Lo not used)
LIM_ENE   = 4  # Hi energy        (Lo not used)

#Limit access: These values are used to index a limit list entry
LIM_CHECK  = 0 # CHK_OFF ... (see below)
LIM_MINVAL = 1 # Lo value: trigger when measurement falls below it
LIM_MAXVAL = 2 # Hi value: trigger when measurement goes above it
LIM_MINHIT = 3 # True = Lo value triggered, False = not
LIM_MAXHIT = 4 # True = Hi value triggered, False = not

# values for the LIM_CHECK field (see above)
CHK_OFF	= 0    # limit is not active 
CHK_MIN	= 1    # check only for Lo 
CHK_MAX = 2    # check only for Hi
CHK_ALL	= 3    # check for both Lo and Hi 

# values for recording
REC_CHANGES= 0
REC_MANUALY= 1
REC_FAST   = 2
REC_1S     = 3
REC_2S     = 5
REC_5S     = 6
REC_10S    = 7
REC_30S    = 8
REC_60S    = 9
REC_300S   = 10


# values for menu returns
MENU_PENDING = 0
MENU_ENTER   = 1
MENU_BACK    = 2 


# values to access the returned value + activation from the edit menu
RETVAL_VAL	 = 0
RETVAL_ACT	 = 1
