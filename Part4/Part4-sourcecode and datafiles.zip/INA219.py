#!/usr/bin/env python3
#MIT License
#
#Copyright (c) 2019 TheHWcave
#
#Permission is hereby granted, free of charge, to any person obtaining a copy
#of this software and associated documentation files (the "Software"), to deal
#in the Software without restriction, including without limitation the rights
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#copies of the Software, and to permit persons to whom the Software is
#furnished to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
#SOFTWARE.
#

import Adafruit_GPIO.I2C as I2C
from CommonDefs import *
from time import sleep
class INA219:
	_ina = None

	INVALID = 9999.9 # invalid value (uninitialized or overflow)
	INA_SHUNT_40MV  = 0
	INA_SHUNT_80MV  = 1
	INA_SHUNT_160MV = 2
	INA_SHUNT_320MV = 3

	
	__INA_REG_CONFIG  = 0x00
	__INA_REG_SHUNT_V = 0x01
	__INA_REG_BUS_V   = 0x02
	__INA_REG_POWER   = 0x03
	__INA_REG_CURRENT = 0x04
	__INA_REG_CAL     = 0x05

	__INA_BUS_16V     = 0
	__INA_BUS_32V     = 1



	__INA_ADC_12B_1S  = 0x03
	__INA_ADC_12B_2S  = 0x09
	__INA_ADC_12B_4S  = 0x0A
	__INA_ADC_12B_8S  = 0x0B
	__INA_ADC_12B_16S = 0x0C
	__INA_ADC_12B_32S = 0x0D
	__INA_ADC_12B_64S = 0x0E
	__INA_ADC_12B_128S= 0x0F
	
	__INA_MODE_S_B_C  = 0x07  # shunt and bus  continuous 
	
	__INA_MAX_SHUNTVOLT = (4000,8000,16000,32000)  # equiv to 40,80,160,320 mV
	

	__CALCUR		  = []
	__CALVOLT		  = []
	
	__MaxVolts	      = 21.0
	__SampleRate	  = __INA_ADC_12B_2S

	__Range = [AUTO_RANGE, INA_SHUNT_320MV]
	__RANGE_MODE      = 0
	__RANGE_VALUE     = 1

	def SetRange(self,mode,mr):
		"""
			Switches between manual range and auto range mode. 
			for auto mode, the range value in the mr  parameter
			is ignored
			for manual mode, the mr parameter must be one of the 
			four definded INA range values 
			"""
		if mode == AUTO_RANGE:
			self.__Range = [AUTO_RANGE, self.INA_SHUNT_320MV]
		else:
			self.__Range = [MAN_RANGE, mr]
			self._configure_INA(mr,self.__SampleRate)
		return None

	def GetRangeValue(self):
		return self.__Range[self.__RANGE_VALUE]
	
	def GetRangeMode(self):
		return self.__Range[self.__RANGE_MODE]
		
	def _writereg(self,reg, regval):
		value_pair = [(regval >> 8)&0xFF,regval & 0xFF]
		INA219._ina.writeList(reg,value_pair)
		return None
		
	def _configure_INA(self,sv,samplerate):
		configval = self.__INA_MODE_S_B_C + \
				0x0008 * samplerate + \
				0x0080 * samplerate + \
				0x0800 * sv   + \
				0x2000 * self.__INA_BUS_32V 
		self._writereg(self.__INA_REG_CONFIG,configval)
		self._writereg(self.__INA_REG_CAL,self.__CALCUR[sv][CALREG])
		return None
	
	def GetShunt(self):
		return self.__SHUNT_OHMS
	
	def Setup(self,NewShunt, NewCALCUR, NewCALVOLT, MaxVolts = 21.0):
		"""
			Setup INA with the shunt and matching Calibration data given
			as parameters. 
		"""
		self.__SHUNT_OHMS = NewShunt
		self.__CALCUR     = NewCALCUR
		self.__CALVOLT    = NewCALVOLT
		self.__MaxVolts	  = MaxVolts
		self._configure_INA(self.__Range[self.__RANGE_VALUE],self.__SampleRate)
		return None

	def SetADCSampling(self,Sampling):
		"""
			Set the INA sampling rate
		"""
		self.__SampleRate = 0b1000 + Sampling
		self._configure_INA(self.__Range[self.__RANGE_VALUE],self.__SampleRate)
		return None
	

		
	def Read_INA(self):
		"""
			Read values from INA, performing auto range if in Auto mode
			
			Auto: read the shunt voltage and compare it to the allowed 
			values starting with the highest range. Stop at the highest 
			range that includes the current value.
			
			Read_INA returns a list of values containing:
			busvolts, current (amps), power, shunt voltage, and an overflow 
			indiator. 
			
			Set the overflow in addition if MaxVolts has been reached or
			exceeded
			
			
			
		"""
		BVREG = 0
		SVREG = 1
		PWREG = 2
		CUREG = 3
		OVBIT = 4
		
		def read_new_measurement():
			newdata = False
			ovbit = False
			while not newdata:
				regval = INA219._ina.readU16BE(self.__INA_REG_BUS_V)
				if regval & 0x0002 == 0x0002:
					newdata = True
				if regval & 0x0001 == 1: #math overflow occured
					ovbit = True
				if self.__SampleRate > self.__INA_ADC_12B_8S:
					newdata = True # don't wait if sampling is set to 16 or more
				else:
					sleep(0.01)
				
			bvreg = regval >> 3
			svreg = INA219._ina.readS16BE(self.__INA_REG_SHUNT_V)
			pwreg = INA219._ina.readU16BE(self.__INA_REG_POWER)
			cureg = INA219._ina.readS16BE(self.__INA_REG_CURRENT)
			return (bvreg,svreg,pwreg,cureg,ovbit)
			
			
		Sample = read_new_measurement()
		
		#print(str(Sample[BVREG])+','+str(Sample[SVREG]))
		r = self.__Range[self.__RANGE_VALUE]
		if self.__Range[self.__RANGE_MODE] == AUTO_RANGE:
			asv = abs(Sample[SVREG])
			nr = self.INA_SHUNT_320MV
			if asv < self.__INA_MAX_SHUNTVOLT[self.INA_SHUNT_320MV]:
				nr = self.INA_SHUNT_40MV
				for tr in range(self.INA_SHUNT_320MV,self.INA_SHUNT_40MV,-1):
					if asv <= self.__INA_MAX_SHUNTVOLT[tr] and asv >= self.__INA_MAX_SHUNTVOLT[tr-1]:
						nr = tr
						break
			if (nr >= self.INA_SHUNT_40MV) and (nr != r):
				self.__Range[self.__RANGE_VALUE] = nr
				self._configure_INA(nr,self.__SampleRate) 
				r = nr
		o = Sample[OVBIT] or (abs(Sample[SVREG]) >= self.__INA_MAX_SHUNTVOLT[r]) # set overflow if shuntrange exceeded
		s = float(Sample[SVREG]) * 0.00001
		p = float(Sample[PWREG]) * 20* self.__CALCUR[r][CURLSB]
		a = float(Sample[CUREG]) * self.__CALCUR[r][CURLSB]
		v = float(Sample[BVREG]) * 0.004
		"""
		Voltage and current correction relies on a SLOPE and INTERCEPT parameter.
			No correction when SLOPE = 1.0 and INTERCEPT = 0
			
			Need to apply reference voltages / currents: REFlo and REFhi 
			and get the corresponding INA readings INAlo and INAhi
			
			SLOPE =  (INA219hi - INA219lo)/(REFhi - REFlo)
			INTERCEPT = INA219lo-SLOPE*REFlo
			
			x = (INAx - INTERCEPT) / SLOPE
		"""
		v = (v - self.__CALVOLT[BVINTER]) / self.__CALVOLT[BVSLOPE]
		a = (a - self.__CALCUR[r][CURINTER]) / self.__CALCUR[r][CURSLOPE]
		
		if not o and (v >= self.__MaxVolts or v+s >=self.__MaxVolts):
			o = True
		return (v,a,p,s,o)

	def __init__(self,NewShunt,NewCALCUR,NewCALVOLT,Samples,MaxVolts=21.0):
		""" setup the INA connection as a singelton with defaults
			every other instance of this class uses the same INA object
		"""
		if INA219._ina == None:
			INA219._ina = I2C.get_i2c_device(address=0x40, busnum=None)
			
		self.Setup(NewShunt,NewCALCUR,NewCALVOLT,MaxVolts)
		self.SetADCSampling(Samples)
