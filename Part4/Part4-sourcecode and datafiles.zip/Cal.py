#!/usr/bin/env python3
#MIT License
#
#Copyright (c) 2019 TheHWcave
#
#Permission is hereby granted, free of charge, to any person obtaining a copy
#of this software and associated documentation files (the "Software"), to deal
#in the Software without restriction, including without limitation the rights
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#copies of the Software, and to permit persons to whom the Software is
#furnished to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
#SOFTWARE.
#

from CommonDefs import *
from LCDpanel import *
from Buttons import ScanButtons, BUTTON1, BUTTON2, BUTTON3, BUTTON4, NO_EVENT,SHORT_PRESS, LONG_PRESS
import copy

class Cal:
	"""
		Displays information but does not allow editing.
		
		Before calling "Show" it needs to be initialized with a list of values (strings) 
		through a call to SetValueList
		
		"Show" displays the first pair of strings on 1st row and
		the text PREV     NEXT BACK on second (no select)
		
		returns MENU_PENDING except as shown below:
		Handles the events
		  Button   press     
			1      short   : previous pair, restart at top if needed
			1      long    : (not used)
			2      short   : (not used)
			2      long    : (not used)
			3      short   : next pair, restart down at 0 if needed
			3      long    : (not used)
			4      short   : return MENU_BACK  
			4      long	   : (not used)
			
	"""

	
	__data   	= None
	__ina		= None
	__disp		= None
	
	
	
	__SVTargets  = [[0.002,0.038],[0.044,0.076],[0.088,0.152],[0.176, 0.304]] 
	__VoltTargets= [1.0,19.0]
	
	__Target     = [0.0,0.0]
	__INAval	 = [0.0,0.0]
	
	__CurCal_old = [[0.0,0.0],[0.0,0.0],[0.0,0.0],[0.0,0.0]]
	__CurCal_new = [[0.0,0.0],[0.0,0.0],[0.0,0.0],[0.0,0.0]]
	__VoltCal_old= [0.0,0.0]
	__VoltCal_new= [0.0,0.0]
	__sl    	 = 0
	__shsel 	 = 0
	__shuntval   = 0

	__firstcall	= True
	__selval	= None
	__cursor	= None

	

	



	def DoCal(self,Ev,SVRange):
		res = MENU_PENDING
		if self.__firstcall:
			self.__firstcall = False
			self.__selval = 0
			WriteLCD(0,1,"    SEL     BACK")
			self.__sl    = self.__data.ReadShunts()
			self.__shsel = self.__data.GetShunt()
			self.__shuntval = self.__data.GetShuntValue()
			self.__CurCal_old  = copy.deepcopy(self.__data.GetCurCalData(self.__shsel))
			self.__VoltCal_old = self.__data.GetVoltCalData()
		
			
			if (SVRange >= SHUNT_40MV) and (SVRange <= SHUNT_320MV):
				"""
					save present current calibration values for that range
					and then turn calibration off by setting slope 
					to 1 and intercept to 0
				"""
				self.__Target[0] = self.__SVTargets[SVRange][0] / self.__shuntval
				self.__Target[1] = self.__SVTargets[SVRange][1] / self.__shuntval
				self.__CurCal_new = copy.deepcopy(self.__CurCal_old)
				self.__CurCal_new[SVRange][CURSLOPE] = 1.0
				self.__CurCal_new[SVRange][CURINTER] = 0.0
				self.__ina.Setup(self.__sl[self.__shsel][SHUNTRES],self.__CurCal_new,self.__VoltCal_old)
			else:
				"""
					save present voltage calibration values
					and then turn calibration off by setting slope 
					to 1 and intercept to 0
				"""
				self.__Target = list(self.__VoltTargets)
				self.__VoltCal_new[BVSLOPE] = 1.0
				self.__VoltCal_new[BVINTER] = 0.0
				self.__ina.Setup(self.__sl[self.__shsel][SHUNTRES],self.__CurCal_old, self.__VoltCal_new)
				
		if (SVRange >= SHUNT_40MV) and (SVRange <= SHUNT_320MV):
			self.__INAval[self.__selval] = self.__data.GetCurrent()
			INAvalstr = self.__disp.Current2StringHiRes(self.__INAval[self.__selval])
			Targetstr = self.__disp.Current2StringHiRes(self.__Target[self.__selval])
		else:
			self.__INAval[self.__selval] = self.__data.GetVolts()
			INAvalstr = self.__disp.Volts2String(self.__INAval[self.__selval])
			Targetstr = self.__disp.Volts2String(self.__Target[self.__selval])
		
		WriteLCD(0,0,Targetstr,False)
		WriteLCD(8,0,INAvalstr,False)
		
		if Ev == (BUTTON2,SHORT_PRESS): # SEL
			if self.__selval == 0:
				self.__selval = 1
			else:
				slope = (self.__INAval[1] - self.__INAval[0]) / (self.__Target[1] - self.__Target[0])
				inter = self.__INAval[0] - slope * self.__Target[0]
				#print(slope, inter)
				if (SVRange >= SHUNT_40MV) and (SVRange <= SHUNT_320MV):
					self.__CurCal_new[SVRange][CURSLOPE] = slope
					self.__CurCal_new[SVRange][CURINTER] = inter
					self.__ina.Setup(self.__sl[self.__shsel][SHUNTRES],self.__CurCal_new,self.__VoltCal_old)
					self.__data.UpdateCalData(self.__shsel,self.__CurCal_new,self.__VoltCal_old)
				else:
					self.__VoltCal_new[BVSLOPE] = slope
					self.__VoltCal_new[BVINTER] = inter
					self.__ina.Setup(self.__sl[self.__shsel][SHUNTRES],self.__CurCal_old,self.__VoltCal_new)
					self.__data.UpdateCalData(self.__shsel,self.__CurCal_old,self.__VoltCal_new)
				res = MENU_ENTER
		elif Ev == (BUTTON4,SHORT_PRESS): # BACK
			self.__ina.Setup(self.__sl[self.__shsel][SHUNTRES],self.__CurCal_old,self.__VoltCal_old)
			res = MENU_BACK
		
					
		if res != MENU_PENDING:
			self.__firstcall = True
		return res
			
			
	def __init__(self, data, ina, disp):
		""" setup a menu of one calibration record. The data consists of 2 pair of values. 
		[Ref_Lo, actual_Lo] [Ref_Hi, actual_Hi]
		the actual values are either curren
		
		things to show as pairs of value strings
		    no editing is allowed, only moving forwards or backwards
		    between the pairs
		    
			The list of pairs are set by the SetValueList method
			
		"""

		
		self.__data    = data
		self.__ina     = ina
		self.__disp	   = disp
		
	
		self.__firstcall = True
		self.__selval = 0

		
