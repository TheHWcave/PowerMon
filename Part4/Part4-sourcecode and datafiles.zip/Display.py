#!/usr/bin/env python3
#MIT License
#
#Copyright (c) 2019 TheHWcave
#
#Permission is hereby granted, free of charge, to any person obtaining a copy
#of this software and associated documentation files (the "Software"), to deal
#in the Software without restriction, including without limitation the rights
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#copies of the Software, and to permit persons to whom the Software is
#furnished to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
#SOFTWARE.
#
from time import sleep,perf_counter

import board
import digitalio
from CommonDefs import *
from LCDpanel import *
from Buttons import ScanButtons, BUTTON1, BUTTON2, BUTTON3, BUTTON4, NO_EVENT,SHORT_PRESS, LONG_PRESS
from INA219 import INA219
from Measure import Measure
#from Recording import Recording


class Display:
	"""
		This class handles the formatting for display and it contains 
		the actual RUN display 
	"""
	__data      = None
	__rec		= None
	__ina		= None
	__relay		= None
	
	__tick		= 0 # increments every 0.2 seconds and wraps after reaching 15
	__Recstate = False
	__Relaystate= False
	

	__FIELD_2STR     = ['Blank','Cap','Energ','Power','RTime',
						'HiVol','AvVol','LoVol','HiAmp','AvAmp','LoAmp',
						'HiPwr','AvPwr','LoPwr','SVolt','Stat']
						
	__FIELD_BLANK    = 0
	__FIELD_CAPACITY = 1
	__FIELD_ENERGY	 = 2
	__FIELD_POWER	 = 3
	__FIELD_RUNNING	 = 4
	__FIELD_HIVOLTS	 = 5
	__FIELD_AVVOLTS	 = 6
	__FIELD_LOVOLTS	 = 7
	__FIELD_HICURRENT= 8
	__FIELD_AVCURRENT= 9
	__FIELD_LOCURRENT= 10
	__FIELD_HIPOWER	 = 11
	__FIELD_AVPOWER	 = 12
	__FIELD_LOPOWER	 = 13
	__FIELD_SHUNTVOL = 14
	__FIELD_STATUS	 = 15 
	__fieldleft_is   = __FIELD_BLANK
	__fieldright_is  = __FIELD_BLANK
	__fieldleft_on   = True
	__manrangeval	 = 0
	__OneFlash		 = False
	__BLOCK8 = chr(CH_BLOCK).ljust(8,chr(CH_BLOCK))


	def SetRecState(self,isOn):
		self.__Recstate = isOn
		return None
		
	def GetRecState(self):
		return self.__Recstate
		
	def Volts2StringLoRes(self,v,unitsymb = True):
		""" takes a volt value in v and returns it as string:
			with unit symbol. 
				12345678
				99.99V  
			without:
				1234567890
				xx.xxx			
		"""
		if not unitsymb:
			res = "{:6.3f}".format(v)
		else:
			res = "{:5.2f}".format(v)+'V'
		return res
		
	def Volts2String(self,v,unitsymb = True):
		""" takes a volt value in v and returns it as string:
			with unit symbol. 
				12345678
				+99.99x
				+999.9x
				+9.999V
				+99.99V  
			without:
				1234567890
				xx.xxx			
		"""
		if not unitsymb:
			res = "{:6.3f}".format(v)
		else:
			if abs(v) < 0.1:
				res = "{:6.2f}".format(1000*v)+chr(CH_MV)
			elif abs(v) < 1.0:
				res = "{:6.1f}".format(1000*v)+chr(CH_MV)
			elif abs(v) < 10.0:
				res = "{:6.3f}".format(v)+'V'
			else:
				res = "{:6.2f}".format(v)+'V'
		return res
		
	

	def Current2StringHiRes(self,a,unitsymb = True):
		""" takes a current value in A and returns it as a string
			trying to use 0.1mA resolution as long as possible
			
			with unit symbol 
				 12345678
				 +xxx.x#  if < 1A
				 +x.xxxx  if < 10A  # 0.1mA but can't show unit 
				 +xx.xxA  if >= 10A
			without:
				1234567890
				+xxx.xxxx
		"""
		if not unitsymb:
			res = "{:+9.4f}".format(a)
		else:
			if abs(a) < 1.0:
				res = "{:+6.1f}".format(a*1000.0) +chr(CH_MA)
			elif abs(a) < 10.0:
				res = "{:+6.4f}".format(a)
			else:
				res = "{:+6.2f}".format(a) + 'A'
		return res
		

	def Current2String(self,a,unitsymb = True):
		""" takes a current value in A and returns it as a string
			with unit symbol 
				 12345678
				 +xxx.x#  if < 1A
				 +x.xxxA  if < 10A 
				 +xx.xxA  if >= 10A
			without:
				1234567890
				+xxx.xxxx
		"""
		if not unitsymb:
			res = "{:+9.4f}".format(a)
		else:
			if abs(a) < 1.0:
				res = "{:+6.1f}".format(a*1000.0) +chr(CH_MA)
			elif abs(a) < 10.0:
				res = "{:+6.3f}".format(a) + 'A'
			else:
				res = "{:+6.2f}".format(a) + 'A'
		return res

	def Power2String(self,p,unitsymb = True):
		""" takes a power value in W and returns it as string:
			with unit symbol:
				1234567
				xxx.xx#  if < 1W
				xxx.xxW" if > 1W
			without:
				1234567890
				xxx.xxxxxx
		"""
		if not unitsymb:
			res = "{:10.6f}".format(p)
		else:
			if abs(p) < 1.0:
				res = "{:6.2f}".format(p*1000)+chr(CH_MW)
			else:
				res = "{:6.2f}".format(p)+'W'
		return res
		
	def Capacity2String(self,c,unitsymb = True):
		""" takes a capacity value in Ah and returns it as string:
			with unit symbol:
				12345678
				0000.0xh" if less than 9999 mAh
				xxx.xxAh" if more
			without:
				1234567890
				xxx.xxxxxx  (Ah)
		"""
		if not unitsymb:
			res = "{:10.6f}".format(c)
		else:
			if abs(c) * 1000 <= 9999.9:
				res = "{:6.1f}".format(c*1000) +chr(CH_MA)+'h'
			else:
				res = "{:6.2f}".format(c) + "Ah"
		return res

	def Energy2String(self,e,unitsymb = True):
		""" takes an energy value in Wh and returns it as string:
			with unit symbol:
				1234567
				0000m"  +unit symbol if less than 9999 mWh
				xx.xx"  +unit symbolif more
			without:
				1234567890
				xxx.xxxxxx  (Wh)
		"""
		if not unitsymb:
			res = "{:10.6f}".format(e)
		else:
			if abs(e) * 1000 <= 9999.9:
				res = "{:6.1f}".format(e*1000) +chr(CH_MW)+'h'
			else:
				res = "{:6.2f}".format(e) +'Wh'
		return res


	def Running2String(self,s,unitsymb = True):
		""" takes a time value in S and returns it as string:
			with unit symbol:
				12345678
				hh:mm:ss
			without:
				12345678
				xxxxxx.x
		"""
		if not unitsymb :
			res = "{:8.1f}".format(s)
		else:
			v = s
			hh = int(v / 3600)
			v = v - 3600*hh
			mm = int(v / 60)
			v = v - 60 * mm
			ss = int(v) 
			res = "{:02d}:{:02d}:{:02d}".format(hh,mm,ss)
		return res


		
	def Status2String(self):
		""" Collects various status items and returns them combined as string:
			12345678
		    srvatce
		              S = 'L' or 'S'  voltage source (load or source)
		              r = 'R' or '.'  R= recording
		              vatce = limits 
		"""

		def Lim2String(kind):
			chk = '-'
			res = [' ',' ']
			setting = self.__data.GetLimit(kind)
			if setting[LIM_CHECK] == CHK_MIN:
				chk=chr(CH_LO)
			elif setting[LIM_CHECK] == CHK_MAX:
				chk=chr(CH_HI)
			elif setting[LIM_CHECK] == CHK_ALL:
				chk=chr(CH_HILO)
			res[0] = chk
			res[1] = chk
			if setting[LIM_MINHIT] or setting[LIM_MAXHIT]: res[1] = '-'
			return res
			
		normal = ''
		alert  = ''
		
		if self.__Recstate:
			ch = 'R'
		else:
			ch = '-'
		normal = normal + ch
		alert  = alert  + ch
		
		if self.__data.GetLoadVolts():
			ch = 'L'
		else:
			ch = 'S'
		normal = normal + ch
		alert  = alert  + ch
		
		res = Lim2String(LIM_VOLTS)
		normal = normal + res[0]
		alert  = alert  + res[1]
		res = Lim2String(LIM_AMPS)
		normal = normal + res[0]
		alert  = alert  + res[1]
		res = Lim2String(LIM_TIME)
		normal = normal + res[0]
		alert  = alert  + res[1]
		res = Lim2String(LIM_CAP)
		normal = normal + res[0]
		alert  = alert  + res[1]
		res = Lim2String(LIM_ENE)
		normal = normal + res[0]
		alert  = alert  + res[1]
		if self._BlinkNow(): 
			res = normal
		else:
			res = alert
		return res.ljust(8)

	def _Range2String(self):
		Rng = [' ',' ']
		if self.__ina.GetRangeMode() == AUTO_RANGE:
			Rng[0] = 'A'
		else:
			Rng[0] = 'a'
		Rng[0] = chr(ord(Rng[0])+self.__ina.GetRangeValue())
		Rng[1] = Rng[0]
		if self.__data.GetOverflow(): Rng[1] = '!'
		if self._BlinkNow(): 
			n = 0
		else:
			n = 1
		return Rng[n]
		
	def Shunt2Str(self):
		#      1234567
		#	   0.005
		return "{:5.3f}".format(self.__ina.GetShunt()) + chr(CH_OHM)
		
	def Field2Str(self):
		return ['L:'+self.__FIELD_2STR[self.__fieldleft_is],
				'R:'+self.__FIELD_2STR[self.__fieldright_is]]
	
	def CalVal2Str(self,cv):
		#      123456
		#       +000n  <0.000001
		#       +000u  0.000001..0.000999 
		#       +000m  0.001..0.999
		#      +1.000  1 .. 9.999
		#      +11.00  >=10
		acv = abs(cv)
		if   acv < 1e-8: 
			res = '{:+3.2f}n'.format(cv*1e9)
		elif acv < 1e-7: 
			res = '{:+3.1f}n'.format(cv*1e9)
		elif acv < 1e-6: 
			res = '{:+3.0f}n'.format(cv*1e9)
		elif acv < 1e-5:
			res = '{:+3.2f}u'.format(cv*1e6)
		elif acv < 1e-4:
			res = '{:+3.1f}u'.format(cv*1e6)
		elif acv < 1e-3:
			res = '{:+3.0f}u'.format(cv*1e6)
		elif acv < 1e-2:
			res = '{:+3.2f}m'.format(cv*1e3)
		elif acv < 1e-1:
			res = '{:+3.1f}m'.format(cv*1e3)
		elif acv < 1:
			res = '{:+3.0f}m'.format(cv*1e3)
		elif acv <10:
			res = '{:+4.3f}'.format(cv)
		else:
			res = '{:+4.2f}'.format(cv)
		return res
		
		

	def _BlinkNow(self):
		return (self.__tick & 0b0010) > 0
		
	def _UpdateNow(self):
		return (self.__tick & 0b0001) > 0

	def Tick(self):
		self.__tick = (self.__tick + 1) & 0b1111
		if self.__OneFlash > 0:
			self.__OneFlash = self.__OneFlash - 1
			if self.__OneFlash == 0:
				LCDBacklight(True)
		return None
		
	
	
	
	def Lim_HiVoltStr(self): return self.Volts2String(self.__data.GetLimit(LIM_VOLTS)[LIM_MAXVAL])+chr(CH_HI)
	def Lim_LoVoltStr(self): return self.Volts2String(self.__data.GetLimit(LIM_VOLTS)[LIM_MINVAL])+chr(CH_LO)
	def Lim_HiAmpsStr(self): return self.Current2String(self.__data.GetLimit(LIM_AMPS)[LIM_MAXVAL])+chr(CH_HI)
	def Lim_LoAmpsStr(self): return self.Current2String(self.__data.GetLimit(LIM_AMPS)[LIM_MINVAL])+chr(CH_LO)
	def Lim_TimeStr(self)  : return self.Running2String(self.__data.GetLimit(LIM_TIME)[LIM_MAXVAL],False)[-7:-2]+'s'+chr(CH_HI)
	def Lim_CAPStr(self)   : return self.Capacity2String(self.__data.GetLimit(LIM_CAP)[LIM_MAXVAL]/1000.0)+chr(CH_HI)
	def Lim_ENEStr(self)   : return self.Energy2String(self.__data.GetLimit(LIM_ENE)[LIM_MAXVAL]/1000.0)+chr(CH_HI)
	


	
		
	def RunDisplay(self,ev):
		"""
			Manages the display when RUN has been selected
			
			it always shows on the 1st line:   Range  Volts   Amps
			
			the 2nd line is divded into a left and right field
			each field can be changed by button presses to show one of a 
			number of optional values
			
			Handles the events
	  Button   press     
		1      short   : change current field to previous value, restart at top if needed
		1      long    : select the left field as current field
		2      short   : in manual range, selects next range, restart at 0 when max reached
		2      long    : toggles between manual and auto range
		3      short   : change current field to next value, restart at bottom if needed
		3      long    : select the right field as current field
		4      short   : return to main menu
		4      long	   : toggle relay state
		"""
		res = MENU_PENDING
		def GetFieldValue(f):
			if 		f == self.__FIELD_CAPACITY	: s = self.Capacity2String(self.__data.GetCapacity())
			elif 	f == self.__FIELD_ENERGY  	: s = self.Energy2String(self.__data.GetEnergy())
			elif 	f == self.__FIELD_POWER 	: s = self.Power2String(self.__data.GetPower())+' '
			elif 	f == self.__FIELD_RUNNING 	: s = self.Running2String(self.__data.GetRunning())
			elif 	f == self.__FIELD_HIVOLTS 	: s = self.Volts2String(self.__data.GetHiVolts())+chr(CH_UP)
			elif 	f == self.__FIELD_AVVOLTS 	: s = self.Volts2String(self.__data.GetAvVolts())+chr(CH_XBAR)
			elif 	f == self.__FIELD_LOVOLTS 	: s = self.Volts2String(self.__data.GetLoVolts())+chr(CH_DN)
			elif 	f == self.__FIELD_HICURRENT	: s = self.Current2String(self.__data.GetHiCurrent())+chr(CH_UP)
			elif 	f == self.__FIELD_AVCURRENT	: s = self.Current2String(self.__data.GetAvCurrent())+chr(CH_XBAR)
			elif 	f == self.__FIELD_LOCURRENT	: s = self.Current2String(self.__data.GetLoCurrent())+chr(CH_DN)
			elif 	f == self.__FIELD_HIPOWER	: s = self.Power2String(self.__data.GetHiPower())+chr(CH_UP)
			elif 	f == self.__FIELD_AVPOWER	: s = self.Power2String(self.__data.GetAvPower())+chr(CH_XBAR)
			elif 	f == self.__FIELD_LOPOWER	: s = self.Power2String(self.__data.GetLoPower())+chr(CH_DN)
			elif 	f == self.__FIELD_SHUNTVOL	: s = self.Volts2String(self.__data.GetShuntVolts())+chr(CH_OHM)
			elif 	f == self.__FIELD_STATUS	: s = self.Status2String()
			else:
				s = ''.ljust(8)
			return s
		
		fields = self.__data.GetRunFields()
		self.__fieldleft_is = fields[0]
		self.__fieldright_is = fields[1]
		
		"""
			0123456789012345
			R 99.99V +x.xxxA
			[ left ][ right]
		"""
		WriteLCD(0,0,self._Range2String()+' ',False)
		WriteLCD(2,0,self.Volts2StringLoRes(self.__data.GetVolts())+' ',False)
		WriteLCD(9,0,self.Current2StringHiRes(self.__data.GetCurrent()),False)
		WriteLCD(0,1,GetFieldValue(self.__fieldleft_is),False)
		WriteLCD(8,1,GetFieldValue(self.__fieldright_is),False)

			


		if ev == (BUTTON1,SHORT_PRESS):
			if self.__fieldleft_on: 
				if self.__fieldleft_is > self.__FIELD_BLANK:
					self.__fieldleft_is = self.__fieldleft_is - 1
				else:
					self.__fieldleft_is = self.__FIELD_STATUS
			else:
				if self.__fieldright_is > self.__FIELD_BLANK:
					self.__fieldright_is = self.__fieldright_is - 1
				else:
					self.__fieldright_is = self.__FIELD_STATUS
			self.__data.SetRunFields([self.__fieldleft_is,self.__fieldright_is])
		elif ev == (BUTTON1,LONG_PRESS):
			self.__fieldleft_on = True
			WriteLCD(1,1,self.__BLOCK8,False)
		elif ev == (BUTTON2,SHORT_PRESS):
			if self.__ina.GetRangeMode() == MAN_RANGE:
				if self.__manrangeval <  SHUNT_320MV:
					self.__manrangeval = self.__manrangeval + 1
				else:
					self.__manrangeval = SHUNT_40MV
				self.__ina.SetRange(MAN_RANGE,self.__manrangeval)
			else:
				if self.__Recstate and self.__data.GetRecOpt() == REC_MANUALY:
					self.__rec.DoRecording(0,True)
					LCDBacklight(False)
					self.__OneFlash = 2
		elif ev == (BUTTON2,LONG_PRESS):
			if self.__ina.GetRangeMode() == AUTO_RANGE:
				self.__ina.SetRange(MAN_RANGE,self.__manrangeval)
			else:
				self.__ina.SetRange(AUTO_RANGE,SHUNT_320MV)
		elif ev == (BUTTON3,SHORT_PRESS):
			if self.__fieldleft_on: 
				if self.__fieldleft_is < self.__FIELD_STATUS:
					self.__fieldleft_is = self.__fieldleft_is + 1
				else:
					self.__fieldleft_is = self.__FIELD_BLANK
			else:
				if self.__fieldright_is < self.__FIELD_STATUS:
					self.__fieldright_is = self.__fieldright_is + 1
				else:
					self.__fieldright_is = self.__FIELD_BLANK
			self.__data.SetRunFields([self.__fieldleft_is,self.__fieldright_is])
		elif ev == (BUTTON3,LONG_PRESS):
			self.__fieldleft_on = False
			WriteLCD(8,1,self.__BLOCK8,False)
		elif ev == (BUTTON4,SHORT_PRESS):
			res = MENU_BACK
		elif ev == (BUTTON4,LONG_PRESS):
			self.__data.ClearAllMeasurements()
		return res
		
		
	def SetRecObject(self,rec):
		""" 
			will be called by the Recording constructor to 
			allow the display access
		"""
		self.__rec = rec
		return None

	def __init__(self,data,ina,relay):
		""" setup class with access to data (measure), INA219 and Relay objects) 
			
		"""
	
		self.__data = data
		self.__ina  = ina
		self.__relay= relay
		self.__tick = 0
